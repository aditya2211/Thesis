/*
Thesis Project on Local Defect Correction
Guide: Prof. J.C. Kalita
Back and forth for steady state heat conduction using cubic spline interpolation
*/

#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include "spline.h"
#define xpt_max 161
#define ypt_max 161
using namespace std;

void interpolate_boundary_conditions(int nox, int noy);
double coarse[xpt_max][ypt_max], finer[xpt_max][ypt_max],x[xpt_max],y[xpt_max];
int i,j,k;

//cubic spline

float* initialise(int n)
{
    float *a ;
    a =  (float*)malloc(n*sizeof(float));
    return a;
}

void cubic_spline(int n,float *x,float *y,float *a,float *b,float *c,float *d)
{
    //S(x) = Sj(x) = aj + bj(x - xj) + cj(x - xj)^2 + dj(x - xj)^3
    //Initialisation
    int i;
    for(int i = 0; i<=n-1; i++)
    {
        a[i] = y[i];
    }

    float *h,*alpha,*l,*mu,*z;

    h = initialise(n);
    for(i=0; i<=n-1; i++)
    {
        h[i] = x[i+1]-x[i];
    }

    alpha = initialise(n+1);
    for(i=1; i<=n-1; i++)
    {
        alpha[i] = 3*(a[i+1]-a[i])/h[i] - 3*(a[i]-a[i-1])/h[i-1];
    }
    //Steps solving a tridiagonal linear system

    l = initialise(n+1);
    mu = initialise(n+1);
    z = initialise(n+1);
    l[0] = 1;
    mu[0] = 0;
    z[0] = 0;

    for(i=1; i<=n-1; i++)
    {
        l[i] = 2.0*(x[i+1]-x[i-1]) - h[i-1]*mu[i-1];
        mu[i] = h[i]/l[i];
        z[i] = (alpha[i] - h[i-1]*z[i-1])/l[i];
    }
    l[n] = 1;
    z[n] = 0;
    c[n] = 0;

    for(i=n-1; i>=0; i--)
    {
        c[i] = z[i] - mu[i]*c[i+1];
        b[i] = (a[i+1] - a[i])/h[i] - h[i]*(c[i+1]+2*c[i])/3.0;
        d[i] = (c[i+1]-c[i])/(3*h[i]);
    }
}


double func(double x)
{
    return 200*x*(x-4);
}

void init_coarse_grid(int nox, int noy, double dx, double dy)
{

    for(j=0; j<=nox; j++)
    {
        coarse[j][0] = func(j*dx);
        coarse[j][noy]=0;
    }
    for(j=1; j<=noy; j++) coarse[0][j]=coarse[nox][j] = 0;
    for(i=1; i<nox; i++) for (j=1; j<noy; j++) coarse[i][j] =0;

}

void update_coarser_grid(int nox,int noy, double dx, double dy)
{


    for(i=2; i<nox; i+=2) for (j=2; j<noy; j+=2) coarse[20+i/2][j/2] = finer[i][j];


}
void update_finer_grid(int nox, int noy, double dx, double dy)
{
    ///ofstream out;
    //top boundary conditin
    for(j=0; j<=nox; j++) finer[j][0] = func(2+j*dx/2);
    //right boundary condition
    for(j=1; j<=noy; j++) finer[nox][j] = 0;
    //left boundary condition
    for(j=2; j<=noy; j+=2) finer[0][j] = coarse[20][(j)/2];
    //lower boundary condition
    for(j=0; j<=nox; j+=2) finer[j][noy] = coarse[20+j/2][5];
    //rest initialization
    //for(i=1;i<nox;i+=2) for (j=1;j<noy;j+=2) finer[i][j] =0;

    for(i=2; i<nox; i+=2) for (j=2; j<noy; j+=2) finer[i][j] =coarse[20+i/2][j/2];

    interpolate_boundary_conditions(nox,noy);

}

//interpolate using cubic spline

void interpolate_boundary_conditions(int nox, int noy)
{
    ofstream out;
    float *x,*y,*a,*b,*c,*d;
    int n = nox/2;

    x = initialise(n+1);
    y = initialise(n+1);
    a = initialise(n);
    b = initialise(n);
    c = initialise(n+1);
    d = initialise(n);
    //lower boundary
    for(j=0; j<=nox/2; j++) x[j] = j;
    for(j=0; j<=nox/2; j++) y[j] = coarse[20+j][5];
    cubic_spline(n,x,y,a,b,c,d);
    for(j=1; j<=nox; j+=2) finer[j][noy] = a[(j-1)/2] + pow(0.5,1)*b[(j-1)/2] + pow(0.5,2)*c[(j-1)/2] +pow(0.5,3)*d[(j-1)/2] ;

    //left boundary
    for(j=0; j<=noy/2; j++) x[j] = j;
    for(j=0; j<=noy/2; j++) y[j] = coarse[20][j];
    cubic_spline(n,x,y,a,b,c,d);
    for(j=1; j<=noy; j+=2) finer[0][j] = a[(j-1)/2] + pow(0.5,1)*b[(j-1)/2] + pow(0.5,2)*c[(j-1)/2] +pow(0.5,3)*d[(j-1)/2];

}


void gs_iter_coarser(double dx, double dy, int nox, int noy, double x, double y, double tol, int max_it)
{
    ofstream out;
    int N = max_it,l=1;
    double lambda,mu,z,norm=0;
    lambda = dx*dx/(dy*dy);
    mu = 2*(1+lambda);

    while(l<N)
    {

        norm=0;
        for(j=noy-1; j>=1; j--)
        {
            for(i=1; i<=nox-1; i++)

            {
                z = (lambda*coarse[i][j+1] + coarse[i-1][j] + coarse[i+1][j] + lambda*coarse[i][j-1])/mu;
                if(abs(coarse[i][j] - z) > norm) norm = abs(coarse[i][j] -z);
                coarse[i][j] = z;
            }

        }


        if(norm < tol)
        {
            break;
        }

        else l++;

    }
}
void gs_iter_finer(double dx, double dy, int nox, int noy, double x, double y, double tol, int max_it)
{
    ofstream out;
    int i,j,k,N = max_it,l=1;
    double lambda,mu,z,norm=0;
    dx = dx/2;
    dy = dy/2;
    lambda = dx*dx/(dy*dy);
    mu = 2*(1+lambda);


    while(l<N)
    {

        norm=0;
        for(j=noy-1; j>=1; j--)
        {
            for(i=1; i<=nox-1; i++)

            {
                z = (lambda*finer[i][j+1] + finer[i-1][j] + finer[i+1][j] + lambda*finer[i][j-1])/mu;
                if(abs(finer[i][j] - z) > norm) norm = abs(finer[i][j] -z);
                finer[i][j] = z;
            }

        }


        if(norm < tol)
        {

            break;
        }

        else l++;


    }


}





int main()
{
    double dx,dy,tol,x,y;
    int nox,noy,N;
    memset(coarse,0,sizeof(coarse));
    memset(finer,0,sizeof(finer));
    //cout<<"Enter the following required parameters : dx, dy, range of x, range of y , tol, max iterations " <<endl;
    //cin>>dx>>dy>>x>>y>>tol>>N;
    dx = .1;
    dy=.1;
    x = 4;
    y=1;
    tol=.00001;
    nox = int(ceil((double)x/(double)dx));
    noy = int(ceil((double)y/(double)dy));
    init_coarse_grid(nox,noy,dx,dy);

    string str;
    cout<<"Select Option:\n1) Run on coarser grid for 'n' iterations \n2) Run on finer grid for  'n' iterations\n3) Run on coarser grid till converence\n4) Run on coarser grid till convergence\n5) Type 'exit' to finish computation\nNB: For convergence, a maximum of 10000 iterations have been set.\n";
    cout<<"Enter your selection:"<<endl;
    cin>>str;
    //cout<<endl;
    while(1)
    {

        if(str=="1")
        {
            cout<<"Enter the number of steps:"<<endl;
            cin>>N;
            gs_iter_coarser(dx,dy,nox,noy,x,y,tol,N);
            update_finer_grid(nox,noy,dx,dy);
        }
        if(str=="2")
        {
            cout<<"Enter the number of steps:"<<endl;
            cin>>N;
            gs_iter_finer(dx,dy,nox,noy,x,y,tol,N);
            update_coarser_grid(nox,noy,dx,dy);

        }
        if(str=="3")
        {
            gs_iter_coarser(dx,dy,nox,noy,x,y,tol,10000);
            update_finer_grid(nox,noy,dx,dy);

        }
        if(str=="4")
        {
            gs_iter_finer(dx,dy,nox,noy,x,y,tol,10000);
            update_coarser_grid(nox,noy,dx,dy);

        }

        if(str=="exit")
        {
            ofstream out;

            out.open("out_gs_coarser.txt");
            for(j = 0; j<=noy; j++)
            {
                for(i = 0 ; i<=nox; i++)
                    out << coarse[i][j] <<" ";
                out<<endl<<endl;
            }

            out.close();


            out.open("out_gs_finer.txt");
            for(j = 0; j<=noy; j++)
            {
                for(i = 0 ; i<=nox; i++)
                    out << finer[i][j] <<" ";
                out<<endl<<endl;
            }

            out.close();


            out.open("coarser_numerical.dat");

            out << "variables = x,y,T"<<endl;
            out << "zone T=\"\","<<"i="<<nox+1<<"j="<<noy+1<<endl;
            for(j = 0; j<=noy; j++)
            {
                for(i = 0 ; i<=nox; i++)
                    out <<dx*i<<" "<<dy*j <<" "<< coarse[i][j] <<endl;
            }

            out.close();


            out.open("finer_numerical.dat");

            out << "variables = x,y,T"<<endl;
            out << "zone T=\"\","<<"i="<<nox+1<<"j="<<noy+1<<endl;
            for(j = 0; j<=noy; j++)
            {
                for(i = 0 ; i<=nox; i++)
                    out <<2+ i*dx/2<<" "<<dy*j/2 <<" "<< finer[i][j] <<endl;
            }

            out.close();


            break;
        }
        cout<<"Enter your selection:"<<endl;
        cin>>str;
//cout<<endl;
    }
    return 1;
}