heatbacknforth.cpp: back and forth routine for steady state heat conduction
nsbacknforth.cpp: back and forth routine for NS psi-omega formulation