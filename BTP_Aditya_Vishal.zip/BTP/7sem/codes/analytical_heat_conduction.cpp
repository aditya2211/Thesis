#include <iostream>
#include<cmath>
#include<math.h>
#include<fstream>
using namespace std;

double func(double x,double y)
{
  double tol = .00001; int k=1;double sum=0,temp=0,n=1;
  temp = (double)1/sinh(-n*M_PI/(double)4)*(double)12800/(n*n*n*M_PI*M_PI*M_PI)*(double)((double)pow(-1,k)-1)*sin(n*M_PI*x/4)*sinh(n*M_PI*(y-1)/4);

  while (abs(temp)>tol)
  { sum = sum+temp;
     n = n+2; k+=2;
     temp = (double)1/sinh(-n*M_PI/(double)4)*(double)12800/(n*n*n*M_PI*M_PI*M_PI)*(double)((double)pow(-1,k)-1)*sin(n*M_PI*x/4)*sinh(n*M_PI*(y-1)/4);
  }
 
return sum;
}


int main()
{  double dx,dy; int nox,noy,i,j;
   cout<<"Enter dx and dy" <<endl;
   cin>>dx>>dy;
   ofstream out;
   
   nox = ceil((double)4/(double)dx);
   noy = ceil((double)1/(double)dy);
   
   out.open("analytical.dat");
  //fprintf(pt1,"variables=x,y,u,v,s,w\n");
    //fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
   out << "variables = x,y,T"<<endl; 
   out << "zone T=\"\","<<"i="<<nox+1<<"j="<<noy+1<<endl;
   for(i=0;i<=noy;i++)
    {  for(j=0;j<=nox;j++)
           out <<dx*j<<" "<<dy*i <<" "<<func(dx*j,dy*i) <<endl;
       //out<<endl; 
    }
  out.close();
return 1;}
