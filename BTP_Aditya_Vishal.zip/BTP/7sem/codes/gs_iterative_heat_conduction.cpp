#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

double func(double x) { return 200*x*(x-4);}

void gs_iter(double dx, double dy, int nox, int noy, double x, double y, double tol, int max_it)
{
   ofstream out;
   int i,j,k,N = max_it,l=1;
   double lambda,grid[nox+1][noy+1],mu,z,norm=0;
   
   lambda = dx*dx/(dy*dy);
   mu = 2*(1+lambda);
   
   for(j=0;j<=nox;j++) {grid[j][0] = func(j*dx);grid[j][noy]=0;}
   for(j=1;j<=noy;j++) grid[0][j]=grid[nox][j] = 0;
   for(i=1;i<nox;i++) for (j=1;j<noy;j++) grid[i][j] =0;
    
     
    while(l<N)
    {     
    
    norm=0;
    for(j=noy-1;j>=1;j--)
    { 
        for(i=1;i<=nox-1;i++)
      
          {  z = (lambda*grid[i][j+1] + grid[i-1][j] + grid[i+1][j] + lambda*grid[i][j-1])/mu;
               if(abs(grid[i][j] - z) > norm) norm = abs(grid[i][j] -z);
             grid[i][j] = z;
          }
  
    } 
  
     
     if(norm < tol) 
       { 
         cout<<"No. of iterations:"<<l<<endl; 
         out.open("out_gs.txt");
          for(j = 0;j<=noy;j++)
           {for(i = 0 ; i<=nox;i++)
              out << grid[i][j] <<" ";
            out<<endl<<endl; }     
        
         out.close();
         break;
       }
   
     else l++;  
  
    
 } 
  
  if(l==N)
        { 
         cout<<"Max iteration reached and NORM is:"<<norm<<endl; 
         out.open("out_gs.txt");
          for(j = 0;j<=noy;j++)
           {for(i = 0 ; i<=nox;i++)
              out << grid[i][j] <<" ";
            out<<endl<<endl;}     
        out.close();
         }
}





int main()
{ double dx,dy,tol,x,y;
  int nox,noy,N;
  
  cout<<"Enter the following required parameters : dx, dy,range of x (b-a), range of y (d-c), tolerence, max iterations " <<endl;
  cin>>dx>>dy>>x>>y>>tol>>N;
 
  nox = ceil((double)x/(double)dx);
  noy = ceil((double)y/(double)dy);
  
  cout<<nox<<" "<<noy<<endl;
  gs_iter(dx,dy,nox,noy,x,y,tol,N);

  return 1;
}