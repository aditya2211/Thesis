/* 

NS numerical solver using local defect correction.

*/

#include <iostream>
#include <stdio.h>
#include <math.h>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
#define m 41
#define n 41
#define re 100
#define h 1/((float) (m-1))
#define mag 4
#define m_finer 41
#define n_finer 41
#define h_finer 1/((float) (4*(m-1)))
#define pi 4*atan(1.0)




using namespace std;

FILE *pt,*pt2,*pt1;
double u[m+5][n+5],v[m+5][n+5],l1=1.0,l2=0.3;
double ii,jj;
double xn[m+5][n+5],xx[m+5][n+5],w[m+5][n+5],err=.5e-4;
double wn[m+5][n+5],wm[m+5][n+5];
double err1=1.0e-4,e[m+5][n+5],e1[m+5][n+5],e2[m+5][n+5],xm[m+5][n+5];
double nn,mu,ta,xx1,yy1,xx2,yy2,k;
float xnew[15],ynew[15],anew[15],bnew[15],cnew[15],dnew[15];

double u_finer[m_finer+5][n_finer+5],v_finer[m_finer+5][n_finer+5],l1_finer=1.0,l2_finer=0.3;
double ii_finer,jj_finer;
double xn_finer[m_finer+5][n_finer+5],xx_finer[m_finer+5][n_finer+5],w_finer[m_finer+5][n_finer+5],err_finer=.5e-4;
double wn_finer[m_finer+5][n_finer+5],wm_finer[m_finer+5][n_finer+5];
double err1_finer=1.0e-4,e_finer[m_finer+5][n_finer+5],e1_finer[m_finer+5][n_finer+5],e2_finer[m_finer+5][n_finer+5],xm_finer[m_finer+5][n_finer+5];
double nn_finer,mu_finer,ta_finer,xx1_finer,yy1_finer,xx2_finer,yy2_finer,k_finer;
//float xnew[15],anew[15],bnew[15],cnew[15],dnew[15],ynew[15];
void cubic_spline(int num,float *x,float *y,float *a,float *b,float *c,float *d);
void interpolate_boundary_conditions(int num);
float* initialise(int num){
  float *a ;
  a =  (float*)malloc(num*sizeof(float));
  return a;
}

void updatefinerfromcoarser()
{
 int i,j;
for(i=0;i<n_finer;i+=mag)
 for(j=0;j<m_finer;j+=mag)
{  


  xn_finer[i][j] = xn[i/mag][j/mag];
  xx_finer[i][j] = xx[i/mag][j/mag];
  xm_finer[i][j] = xm[i/mag][j/mag];

  w_finer[i][j]  = w[i/mag][j/mag];
  wn_finer[i][j] = wn[i/mag][j/mag];
  wm_finer[i][j] = wm[i/mag][j/mag];

}


interpolate_boundary_conditions(n_finer/mag);

}

void updatecoarserfromfiner()
{
int i,j;
for(i=0;i<n_finer;i+=mag)
 for(j=0;j<m_finer;j+=mag)
{  


  xn[i/mag][j/mag] = xn_finer[i][j] ;
  xx[i/mag][j/mag] = xx_finer[i][j];
  xm[i/mag][j/mag] = xm_finer[i][j];

  w[i/mag][j/mag] =  w_finer[i][j] ;
  wn[i/mag][j/mag] =  wn_finer[i][j];
  wm[i/mag][j/mag] = wm_finer[i][j] ;

}

}

double norm(double s[][n+5])
  //double s[][n+5];
  {
    int i,j;
    double x2n=0.0;

    for(j=0;j<n;j++)for(i=0;i<m;i++)  x2n += s[i][j]*s[i][j];
    x2n=sqrt(x2n);
    return(x2n);

  }

  double vecmul(double v[][n+5],double s[][n+5])
  //double ;
  {
   int i,j;
   double r=0.0;
   for(j=0;j<n;j++)for(i=0;i<m;i++)  r += v[i][j]*s[i][j];
   return(r);
  }
 double max(double s[][n+5])
     {
	int i,j;
        double v=fabs(s[0][0]);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         if(fabs(s[i][j])>=v)  v=fabs(s[i][j]);
         else v=v;
       }
         return(v);

     }

void interpolate_boundary_conditions(int num)
{ ofstream out;
  float *x,*y,*a,*b,*c,*d;
  int i,j;
  
  x = initialise(num+1);
  y = initialise(num+1);
  a = initialise(num);
  b = initialise(num);
  c = initialise(num+1);
  d = initialise(num);
  //top boundary
  for(j=0;j<=num;j++) x[j] = j;
  
  for(j=0;j<=num;j++) y[j] = xx[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xx_finer[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
  for(j=0;j<=num;j++) y[j] = w[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)w_finer[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
  for(j=0;j<=num;j++) y[j] = xm[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xm_finer[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
  for(j=0;j<=num;j++) y[j] = wm[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)wm_finer[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  

  //right boundary

  for(j=0;j<=num;j++) y[j] = xx[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xx_finer[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
  for(j=0;j<=num;j++) {y[j] = w[num][j]; cout<<"check$$"<<y[j]<<endl;}
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++){w_finer[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
cout<<"checkinterpolate"<<w_finer[n_finer-1][mag*j + i]<<endl;
  }
  for(j=0;j<=num;j++) y[j] = xm[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xm_finer[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
  for(j=0;j<=num;j++) y[j] = wm[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)wm_finer[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;	
  

  //left
for(j=0;j<=num;j++) y[j] = w[0][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)w_finer[0][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;

for(j=0;j<=num;j++) y[j] = wm[0][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)wm_finer[0][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;





  //bottom	
for(j=0;j<=num;j++) y[j] = w[j][0];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)w_finer[mag*j+i][0] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
for(j=0;j<=num;j++) y[j] = wm[j][0];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)wm_finer[mag*j+i][0] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
}
void initialise_coarser()
{
  int i,j;
  for(j=1;j<n-1;j++)
   {
	u[0][j]=v[0][j]=0;
	u[m-1][j]=v[m-1][j]=0;
   }

  for(i=0;i<m;i++)
   {
	u[i][n-1]=1;
	u[i][0]=v[i][0]=v[i][n-1]=0; 
   }

for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u[i][j]=v[i][j]=0.000;

  for(j=0;j<n;j++)
	  {
			xx[0][j]=xn[0][j]=0.00;
			xx[m-1][j]=xn[m-1][j]=0.00;
	  }


	
     for(i=1;i<m-1;i++)
	{
	  xx[i][0]=xn[i][0]=0.00;
	  xx[i][n-1]=xn[i][n-1]=0.00;
	}
	for(j=0;j<n;j++)for(i=0;i<m;i++)
          {
            xx[i][j]=xn[i][j]=0.00;
            w[i][j]=wn[i][j]=wm[i][j]=-2*j*h*h;
          }

        w[0][0]=w[m-1][0]=0.0;w[0][n-1]=w[m-1][n-1]=-(m-1);


}

void initialise_finer()
{
  int i,j;
  for(j=1;j<n_finer-1;j++)
   {
	u_finer[0][j]=v_finer[0][j]=0;
	u_finer[m_finer-1][j]=v_finer[m_finer-1][j]=0;
   }

  for(i=0;i<m_finer;i++)
   {
	u_finer[i][n_finer-1]=1;
	u_finer[i][0]=v_finer[i][0]=v_finer[i][n_finer-1]=0; 
   }

for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)u_finer[i][j]=v_finer[i][j]=0.000;

  for(j=0;j<n_finer;j++)
	  {
			xx_finer[0][j]=xn_finer[0][j]=0.00;
			xx_finer[m_finer-1][j]=xn_finer[m_finer-1][j]=0.00;
	  }


	
     for(i=1;i<m_finer-1;i++)
	{
	  xx_finer[i][0]=xn_finer[i][0]=0.00;
	  xx_finer[i][n_finer-1]=xn_finer[i][n_finer-1]=0.00;
	}
	for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)
          {
            xx_finer[i][j]=xn_finer[i][j]=0.00;
            w_finer[i][j]=wn_finer[i][j]=wm_finer[i][j]=-2*j*h_finer*h_finer;
          }

        w_finer[0][0]=w_finer[m_finer-1][0]=0.0;w_finer[0][n_finer-1]=w_finer[m_finer-1][n_finer-1]=-(m_finer-1);


updatefinerfromcoarser();



//cout<<w[10][0]<<" "<<w[10][1]<<" "<<w[10][2]<<endl;
//cout<<(float)((1/((float) (mag)))*(float)3);

//for(int ok=0;ok<=10;ok++) cout<<w[ok][10]<<" "; cout<<endl;
//for(int ok=0;ok<=40;ok++) cout<<w_finer[ok][40]<<" "; cout<<endl;
//cout<<w_finer[40][3]<<" "<<w[40][4]<<" "<<w[40][7]<<endl;
//fitting boundary with cubic splines;




}

void coarse_solver()
{   int i,j,it=0,it1=0,it2=0,tag;
do
 {

	tag=1;it++;

  it1=0;
   do 
     {
     it1++;
     for(j=0;j<n;j++)for(i=0;i<m;i++)xn[i][j]=xx[i][j];
	

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         xx[i][j]=0.25*(xx[i+1][j]+xx[i-1][j]+xx[i][j+1]+xx[i][j-1]+h*h*w[i][j]);
         xx[i][j]=xn[i][j]+l1*(xx[i][j]-xn[i][j]);

         }

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)e[i][j]=xn[i][j]-xx[i][j];


}while(max(e)>0.0001);
                 /* Calculation of u and v*/

	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         u[i][j]=0.5*(m-1)*(xx[i][j+1]-xx[i][j-1]);
         v[i][j]=0.5*(m-1)*(xx[i-1][j]-xx[i+1][j]);
         }




        for(j=1;j<n-1;j++){w[0][j]=-2*xx[1][j]/(h*h);w[m-1][j]=-2*xx[m-2][j]/(h*h);}
        for(i=1;i<m-1;i++){w[i][0]=-2*xx[i][1]/(h*h);w[i][n-1]=-2*(h+xx[i][n-2])/(h*h);}


  it2=0;
do
  {
     it2++;
     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)wn[i][j]=w[i][j];
	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         w[i][j]=0.125*((2-re*h*u[i][j])*w[i+1][j]+(re*h*u[i][j]+2)*w[i-1][j]+(2-re*h*v[i][j])*w[i][j+1]+(re*h*v[i][j]+2)*w[i][j-1]);
         w[i][j]=wn[i][j]+l2*(w[i][j]-wn[i][j]);
         }

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)e[i][j]=w[i][j]-wn[i][j];

}while(max(e)>0.0001);


     for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
           e1[i][j]=w[i][j]-wm[i][j];
          w[i][j]=wm[i][j]+0.05*(w[i][j]-wm[i][j]);
        }
     for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
          e2[i][j]=xx[i][j]-xm[i][j]; 
          xx[i][j]=xm[i][j]+1.0*(xx[i][j]-xm[i][j]);
        }
     for(j=0;j<n;j++)for(i=0;i<m;i++)wm[i][j]=w[i][j];
     for(j=0;j<n;j++)for(i=0;i<m;i++)xm[i][j]=xx[i][j];

printf("%d %d %d %lf %lf %e\n",it,it1,it2,u[1][1],max(xx),max(e1));

		
	 if(max(e1)<err1)tag=0;


}while(tag==1);

		 pt1=fopen("dct_100.dat","w+");
	  fprintf(pt1,"variables=x,y,u,v,s,w\n");
	  fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n;j++) for(i=0;i<m;i++)
		{
 fprintf(pt1,"%lf %lf %e %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j],w[i][j]);

		}
		fclose(pt1);

		 pt1=fopen("coarser_w.dat","w+");

for(j=0;j<=10;j++) 
	{for(i=0;i<=10;i++)
		{
 fprintf(pt1,"%lf ",w[i][j]);
    
		}
		fprintf(pt1,"\n");}

		 pt1=fopen("coarser_xx.dat","w+");

for(j=0;j<=10;j++) 
	{for(i=0;i<=10;i++)
		{
 fprintf(pt1,"%lf ",xx[i][j]);
    
		}
		fprintf(pt1,"\n");}

		 pt1=fopen("coarser_diff.dat","w+");



}

typedef vector<double> vec;

struct SplineSet{
    double a;
    double b;
    double c;
    double d;
    double x;
};

vector<SplineSet> spline(vec &x, vec &y)
{
    int num = x.size()-1;
    vec a;
    a.insert(a.begin(), y.begin(), y.end());
    vec b(num);
    vec d(num);
    vec diff;

    for(int i = 0; i < num; ++i)
        diff.push_back(x[i+1]-x[i]);

    vec alpha;
    for(int i = 0; i < num; ++i)
        alpha.push_back( 3*(a[i+1]-a[i])/diff[i] - 3*(a[i]-a[i-1])/diff[i-1]  );

    vec c(num+1);
    vec l(num+1);
    vec mu(num+1);
    vec z(num+1);
    l[0] = 1;
    mu[0] = 0;
    z[0] = 0;

    for(int i = 1; i < num; ++i)
    {
        l[i] = 2 *(x[i+1]-x[i-1])-diff[i-1]*mu[i-1];
        mu[i] = diff[i]/l[i];
        z[i] = (alpha[i]-diff[i-1]*z[i-1])/l[i];
    }

    l[num] = 1;
    z[num] = 0;
    c[num] = 0;

    for(int j = num-1; j >= 0; --j)
    {
        c[j] = z [j] - mu[j] * c[j+1];
        b[j] = (a[j+1]-a[j])/diff[j]-diff[j]*(c[j+1]+2*c[j])/3;
        d[j] = (c[j+1]-c[j])/3/diff[j];
    }

    vector<SplineSet> output_set(num);
    for(int i = 0; i < num; ++i)
    {
        output_set[i].a = a[i];
        output_set[i].b = b[i];
        output_set[i].c = c[i];
        output_set[i].d = d[i];
        output_set[i].x = x[i];
    }
    return output_set;
}
void interpolatetoprightomega()
{

int num = n_finer/mag;
int i,j;
// float *x,*y,*a,*b,*c,*d;
//   int i,j;
  
//   x = initialise(num+1);
//   y = initialise(num+1);
//   a = initialise(num);
//   b = initialise(num);
//   c = initialise(num+1);
//   d = initialise(num);
//   //top boundary
//   for(j=0;j<=num;j++) x[j] = j;


// //top
// //int i,j;
// for(i=0;i<n_finer;i+=mag) {w_finer[i][m_finer-1] = (xx[i/mag][11] - 2*xx[i/mag][10]	+ xx_finer[i][m_finer-5])/(h*h); cout<<w_finer[i][m_finer-1]<<endl;}

//  // vector<double> X(11), Y(11);
//  // for(j=0;j<=num;j++) X[j] = j;
//  // 	for(j=0;j<n;j+=mag) Y[j] = w_finer[j][m_finer-1];

//  // 		vector<SplineSet> cs = spline(X, Y);
//    //X[0]=0.1; X[1]=0.4; X[2]=1.2; X[3]=1.8; X[4]=2.0;
//    //Y[0]=0.1; Y[1]=0.7; Y[2]=0.6; Y[3]=1.1; Y[4]=0.9;

//   //  tk::spline s;
//   //  s.set_points(X,Y); 
//   // cout<<"--------"<<endl;

//    //cout<<Y[4]<<" hjhjk "<<Y[5]<<endl;
//    //cout<<cs[4].d*1.25*1.25*1.25 +cs[4].c*1.25*1.25 +cs[4].b*1.25 +cs[4].a <<endl;
// //for(int i = 0; i < cs.size(); ++i)
//         //cout << cs[i].d << "\t" << cs[i].c << "\t" << cs[i].b << "\t" << cs[i].a << endl;
//   for(j=0;j<n_finer;j+=mag) y[j/mag] = w_finer[j][m_finer-1];
//   cubic_spline(n_finer/mag,x,y,a,b,c,d);
//   for(j=0;j<num;j++) for(i=1;i<mag;i++){w_finer[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
// cout<<"---"<<w_finer[mag*j +i][m_finer-1]<<endl;
//   }

// //right
// for(i=0;i<m_finer;i+=mag){
// w_finer[n_finer-1][i] = (xx[n_finer/mag+1][i/mag] - 2*xx[10][i/mag]	+ xx_finer[n_finer-5][i])/(h*h); cout<<w_finer[n_finer-1][i]<<endl;}
// for(j=0;j<m_finer;j+=mag) y[j/mag] = w_finer[n_finer-1][j];
// cubic_spline(m_finer/mag,x,y,a,b,c,d);

// //cout<<" "<<a1[1]<<" "<<b1[1]<<" "<<c1[1]<<endl;
// for(j=0;j<num;j++) for(i=1;i<mag;i++){w_finer[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;	
//  cout<<"---"<<w_finer[m_finer-1][mag*j +i]<<endl; 
// }

for(j=0;j<=num;j++) xnew[j] = j;


//top
//int i,j;
//w_finer[i][m_finer-1]=0.125*((2-re*h_finer*u_finer[i][m_finer-1])*w_finer[i+1][m_finer-1]+(re*h_finer*u_finer[i][m_finer-1]+2)*w_finer[i-1][m_finer-1]+(2-re*h_finer*v_finer[i][m_finer-1])*w_finer[i][j+1]+(re*h_finer*v_finer[i][j]+2)*w_finer[i][j-1]);
//w_finer[i][m_finer-1]=0.125*((2-re*h*u[i/mag][10])*w_finer[i+1][36]+(re*h*u_finer[i][36]+2)*w_finer[i-1][]+(2-re*h*v[i/mag][9])*w[i/mag][11]+(re*h*v[i/mag][10]+2)*w[i/mag][9]);
//w_finer[i][m_finer-1]=0.125*((2-re*h*u[i/mag][10])*w[i/mag+1][9]+(re*h*u[i/mag][9]+2)*w[i/mag-1][9]+(2-re*h*v[i/mag][9])*w[i/mag][11]+(re*h*v[i/mag][10]+2)*w[i/mag][9]);//

//w_finer[i][m_finer-1]=0.125*((2-re*h*u_finer[i][m_finer-1])*w_finer[i+4][m_finer-1]+(re*h*u_finer[i][m_finer-1]+2)*w_finer[i+4][m_finer-1]+(2-re*h*v_finer[i][m_finer-1])*w[i/mag][10+1]+(re*h*v_finer[i][m_finer-1]+2)*w_finer[i][m_finer-1-4]);	
for(i=mag;i<n_finer-mag;i+=mag) { 
w_finer[i][m_finer-1]=0.125*((2-re*h*u_finer[i][m_finer-1])*w_finer[i+4][m_finer-1]+(re*h*u_finer[i][m_finer-1]+2)*w_finer[i-4][m_finer-1]+(2-re*h*v_finer[i][m_finer-1])*w[i/mag][10+1]+(re*h*v_finer[i][m_finer-1]+2)*w_finer[i][m_finer-4-1]); cout<<"qwertyuio   "<<w_finer[i][m_finer-1]-w[i/mag][10]<<endl;}
i=n_finer-1;

w_finer[i][m_finer-1]=0.125*((2-re*h*u_finer[i][m_finer-1])*w[i/mag +1][i/mag]+(re*h*u_finer[i][m_finer-1]+2)*w_finer[i-4][m_finer-1]+(2-re*h*v_finer[i][m_finer-1])*w[i/mag][10+1]+(re*h*v_finer[i][m_finer-1]+2)*w_finer[i][m_finer-4-1]);
 



 // vector<double> X(11), Y(11);
 // for(j=0;j<=num;j++) X[j] = j;
 // 	for(j=0;j<n;j+=mag) Y[j] = w_finer[j][m_finer-1];

 // 		vector<SplineSet> cs = spline(X, Y);
   //X[0]=0.1; X[1]=0.4; X[2]=1.2; X[3]=1.8; X[4]=2.0;
   //Y[0]=0.1; Y[1]=0.7; Y[2]=0.6; Y[3]=1.1; Y[4]=0.9;

  //  tk::spline s;
  //  s.set_points(X,Y); 
  // cout<<"--------"<<endl;

   //cout<<Y[4]<<" hjhjk "<<Y[5]<<endl;
   //cout<<cs[4].d*1.25*1.25*1.25 +cs[4].c*1.25*1.25 +cs[4].b*1.25 +cs[4].a <<endl;
//for(int i = 0; i < cs.size(); ++i)
        //cout << cs[i].d << "\t" << cs[i].c << "\t" << cs[i].b << "\t" << cs[i].a << endl;

//w_finer[i][j]=0.125*((2-re*h_finer*u_finer[i][j])*w_finer[i+1][j]+(re*h_finer*u_finer[i][j]+2)*w_finer[i-1][j]+(2-re*h_finer*v_finer[i][j])*w_finer[i][j+1]+(re*h_finer*v_finer[i][j]+2)*w_finer[i][j-1]);
  for(j=0;j<n_finer;j+=mag) ynew[j/mag] = w_finer[j][m_finer-1];
  cubic_spline(n_finer/mag,xnew,ynew,anew,bnew,cnew,dnew);
  for(j=0;j<num;j++) for(i=1;i<mag;i++){w_finer[mag*j+i][m_finer-1] = anew[j] + pow((float)((1/((float) (mag)))*(float)i),1)*bnew[j] + pow((float)((1/((float) (mag)))*(float)i),2)*cnew[j] +pow((float)((1/((float) (mag)))*(float)i),3)*dnew[j] ;
//cout<<"---"<<w_finer[mag*j +i][m_finer-1]<<endl;
  }

//right

//i=0;
//w_finer[n_finer-1][j]=0.125*((2-re*h*u_finer[n_finer-1][j])*w_finer[n_finer-1-4][j]+(re*h*u_finer[n_finer-1][j]+2)*w_finer[i-1][j]+(2-re*h_finer*v_finer[i][j])*w_finer[i][j+1]+(re*h_finer*v_finer[i][j]+2)*w_finer[i][j-1]);
i=n_finer-1;
for(j=mag;j<m_finer-mag;j+=mag){
//w_finer[n_finer-1][i] = -1*(xx[11][i/mag] - 2*xx[10][i/mag]	+ xx[9][i/mag])/(h*h);
	//w_finer[i][j]=0.125*((2-re*h_finer*u_finer[i][j])*w_finer[i+1][j]+(re*h_finer*u_finer[i][j]+2)*w_finer[i-1][j]+(2-re*h_finer*v_finer[i][j])*w_finer[i][j+1]+(re*h_finer*v_finer[i][j]+2)*w_finer[i][j-1]);
 w_finer[n_finer-1][j]=0.125*((2-re*h*u_finer[i][j])*w[i/mag+1][j/mag]+(re*h*u_finer[i][j]+2)*w_finer[i-4][j]+(2-re*h*v_finer[i][j])*w_finer[i][j+4]+(re*h*v_finer[i][j]+2)*w_finer[i][j-4]);
        
 }
for(j=0;j<m_finer;j+=mag) ynew[j/mag] = w_finer[n_finer-1][j];
cubic_spline(m_finer/mag,xnew,ynew,anew,bnew,cnew,dnew);

//cout<<" "<<a1[1]<<" "<<b1[1]<<" "<<c1[1]<<endl;
for(j=0;j<num;j++) for(i=1;i<mag;i++){w_finer[n_finer-1][mag*j+i] = anew[j] + pow((float)((1/((float) (mag)))*(float)i),1)*bnew[j] + pow((float)((1/((float) (mag)))*(float)i),2)*cnew[j] +pow((float)((1/((float) (mag)))*(float)i),3)*dnew[j] ;	
 //cout<<"---"<<w_finer[m_finer-1][mag*j +i]<<endl; 
}

}


void interpolatetoprightpsi()
{
  

  int num= n_finer/mag;
  int i,j;
  for(j=0;j<=num;j++) xnew[j] = j;
  j = m_finer-1;
  for(i=mag;i<n_finer-mag;i+=mag)  
  xx_finer[i][m_finer-1] = 0.25*(xx_finer[i+4][j]+xx_finer[i-4][j]+xx[i/mag][j/mag+1]+xx_finer[i][j-4]+h*h*w_finer[i][j]);
  
  xx_finer[j][j] = 0.25*(xx[i/mag +1][j/mag]+xx_finer[i-4][j]+xx[i/mag][j/mag+1]+xx_finer[i][j-4]+h*h*w_finer[i][j]);

  for(j=0;j<n_finer;j+=mag) ynew[j/mag] = xx_finer[j][m_finer-1];
  cubic_spline(m_finer/mag,xnew,ynew,anew,bnew,cnew,dnew);

 for(j=0;j<num;j++) for(i=1;i<mag;i++){xx_finer[mag*j+i][m_finer-1] = anew[j] + pow((float)((1/((float) (mag)))*(float)i),1)*bnew[j] + pow((float)((1/((float) (mag)))*(float)i),2)*cnew[j] +pow((float)((1/((float) (mag)))*(float)i),3)*dnew[j] ;
//cout<<"---"<<w_finer[mag*j +i][m_finer-1]<<endl;
  }

 //right 
  j = m_finer-1;
  for(i=mag;i<n_finer-mag;i+=mag)
 xx_finer[n_finer-1][i] = 0.25*(xx[j/mag+1][i/mag]+xx_finer[j-4][i]+xx_finer[j][i+4]+xx_finer[j][i-4]+h*h*w_finer[j][i]);

for(j=0;j<n_finer;j+=mag) ynew[j/mag] = xx_finer[m_finer-1][j];
  cubic_spline(m_finer/mag,xnew,ynew,anew,bnew,cnew,dnew);  
//cout<<" "<<a1[1]<<" "<<b1[1]<<" "<<c1[1]<<endl;
for(j=0;j<num;j++) for(i=1;i<mag;i++){xx_finer[n_finer-1][mag*j+i] = anew[j] + pow((float)((1/((float) (mag)))*(float)i),1)*bnew[j] + pow((float)((1/((float) (mag)))*(float)i),2)*cnew[j] +pow((float)((1/((float) (mag)))*(float)i),3)*dnew[j] ;	
 //cout<<"---"<<w_finer[m_finer-1][mag*j +i]<<endl; 
}

}

void fine_solver()
{   int i,j,it=0,it1=0,it2=0,tag;
	//cout<<h_finer<<endl;
do
 {

	tag=1;it++;

//interpolatetoprightpsi();

  it1=0;
   do 
     {
     it1++;

     
//interpolatetoprightpsi();
     for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)xn_finer[i][j]=xx_finer[i][j];
	

     for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)
         {
         xx_finer[i][j]=0.25*(xx_finer[i+1][j]+xx_finer[i-1][j]+xx_finer[i][j+1]+xx_finer[i][j-1]+h_finer*h_finer*w_finer[i][j]);
         xx_finer[i][j]=xn_finer[i][j]+l1_finer*(xx_finer[i][j]-xn_finer[i][j]);

         }

     for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)e_finer[i][j]=xn_finer[i][j]-xx_finer[i][j];


}while(max(e_finer)>0.0001);
                 /* Calculation of u and v*/

	for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)
         {
         u_finer[i][j]=0.5*160*(xx_finer[i][j+1]-xx_finer[i][j-1]);
         v_finer[i][j]=0.5*160*(xx_finer[i-1][j]-xx_finer[i+1][j]);
         }



    for(j=1;j<n_finer-1;j++)w_finer[0][j]=-2*xx_finer[1][j]/(h_finer*h_finer);//w_finer[m_finer-1][j]=-2*xx_finer[m_finer-2][j]/(h_finer*h_finer);}
    for(i=1;i<m_finer-1;i++)w_finer[i][0]=-2*xx_finer[i][1]/(h_finer*h_finer);//w_finer[i][n_finer-1]=-2*(h_finer+xx_finer[i][n_finer-2])/(h_finer*h_finer);}

     interpolatetoprightomega();
//////////////////
//////////////////         
         //for(j=1;j<n_finer-1;j++){w_finer[0][j]=-2*xx_finer[1][j]/(h_finer*h_finer);w_finer[m_finer-1][j]=-2*xx_finer[m_finer-2][j]/(h_finer*h_finer);}
         //for(i=1;i<m_finer-1;i++){w_finer[i][0]=-2*xx_finer[i][1]/(h_finer*h_finer);w_finer[i][n_finer-1]=-2*(h_finer+xx_finer[i][n_finer-2])/(h_finer*h_finer);}
        // //updating omega using finite differential equations

        

  it2=0;
do
  {
     it2++;
     for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)wn_finer[i][j]=w_finer[i][j];
	for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)
         {
         w_finer[i][j]=0.125*((2-re*h_finer*u_finer[i][j])*w_finer[i+1][j]+(re*h_finer*u_finer[i][j]+2)*w_finer[i-1][j]+(2-re*h_finer*v_finer[i][j])*w_finer[i][j+1]+(re*h_finer*v_finer[i][j]+2)*w_finer[i][j-1]);
         w_finer[i][j]=wn_finer[i][j]+l2_finer*(w_finer[i][j]-wn_finer[i][j]);
         }

     for(j=1;j<n_finer-1;j++)for(i=1;i<m_finer-1;i++)e_finer[i][j]=w_finer[i][j]-wn_finer[i][j];
     	

}while(max(e_finer)>0.0001);


     for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)
        {
           e1_finer[i][j]=w_finer[i][j]-wm_finer[i][j];
          w_finer[i][j]=wm_finer[i][j]+0.05*(w_finer[i][j]-wm_finer[i][j]);
        }
     for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)
        {
          e2_finer[i][j]=xx_finer[i][j]-xm_finer[i][j]; 
          xx_finer[i][j]=xm_finer[i][j]+1.0*(xx_finer[i][j]-xm_finer[i][j]);
        }
     for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)wm_finer[i][j]=w_finer[i][j];
     for(j=0;j<n_finer;j++)for(i=0;i<m_finer;i++)xm_finer[i][j]=xx_finer[i][j];

printf("%d %d %d %lf %lf %e\n",it,it1,it2,u_finer[4][4],max(xx_finer),max(e1_finer));

		
	 if(max(e1_finer)<err1_finer)tag=0;

	  
cout<<it2<<" "<<w_finer[40][4]<<endl;



}while(tag==1);

		 pt1=fopen("dct_finer_100.dat","w+");
	  fprintf(pt1,"variables=x,y,u,v,s,w\n");
	  fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n_finer;j++) for(i=0;i<m_finer;i++)
		{
 fprintf(pt1,"%lf %lf %e %e %e %e\n",i*h_finer,j*h_finer,u_finer[i][j],v_finer[i][j],xx_finer[i][j],w_finer[i][j]);
    
		}
		fclose(pt1);
cout<<"check "<<u_finer[4][4]<<"check"<<v_finer[4][4]<<endl;

{pt1=fopen("finer_w.dat","w+");

for(j=0;j<n_finer;j++) 
	{for(i=0;i<m_finer;i++)
		{
 fprintf(pt1,"%lf ",w_finer[i][j]);
    
		}
		fprintf(pt1,"\n");}

		 pt1=fopen("finer_xx.dat","w+");

for(j=0;j<n_finer;j++) 
	{for(i=0;i<m_finer;i++)
		{
 fprintf(pt1,"%lf ",xx_finer[i][j]);
    
		}
		fprintf(pt1,"\n");}

fclose(pt1);}
}


int main()
{
	
  initialise_coarser();
  coarse_solver();
  
  initialise_finer();
  fine_solver();
  updatecoarserfromfiner();
  coarse_solver();
  updatefinerfromcoarser();
  fine_solver();
  updatecoarserfromfiner();
  coarse_solver();
  updatefinerfromcoarser();
  fine_solver();
  updatecoarserfromfiner();
  coarse_solver();
  updatefinerfromcoarser();
  fine_solver();
  updatecoarserfromfiner();
  coarse_solver();
  updatefinerfromcoarser();
  fine_solver();
		 }

 

  

 void cubic_spline(int num,float *x,float *y,float *a,float *b,float *c,float *d){
  //S(x) = Sj(x) = aj + bj(x - xj) + cj(x - xj)^2 + dj(x - xj)^3
  //Initialisation
  int i;
  for(int i = 0;i<=num-1;i++){
    a[i] = y[i];
  }
  
  float *x_h,*alpha,*l,*mu,*z;
  
  x_h = initialise(num);
  for(i=0;i<=num-1;i++){
    x_h[i] = x[i+1]-x[i];
  }

  alpha = initialise(num+1);
  for(i=1;i<=num-1;i++){
    alpha[i] = 3*(a[i+1]-a[i])/x_h[i] - 3*(a[i]-a[i-1])/x_h[i-1];
  }
  //Steps solving a tridiagonal linear system

  l = initialise(num+1);
  mu = initialise(num+1);
  z = initialise(num+1);
  l[0] = 1; mu[0] = 0; z[0] = 0;

  for(i=1;i<=num-1;i++){
    l[i] = 2.0*(x[i+1]-x[i-1]) - x_h[i-1]*mu[i-1];
    mu[i] = x_h[i]/l[i];
    z[i] = (alpha[i] - x_h[i-1]*z[i-1])/l[i];
  }
  l[num] = 1; z[num] = 0; c[num] = 0;

  for(i=num-1;i>=0;i--){
    c[i] = z[i] - mu[i]*c[i+1];
    b[i] = (a[i+1] - a[i])/x_h[i] - x_h[i]*(c[i+1]+2*c[i])/3.0;
    d[i] = (c[i+1]-c[i])/(3*x_h[i]);
  }
}
    