// Program on LID DRIVEN CAVITY problem //
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#define i_max 129
#define j_max 129
#define err_max 0.00001
main(){
  FILE *pt;
  int i,j,Re=400,U=1;
  long double w[i_max+1][j_max+1],z[i_max+1][j_max+1],w_fin[i_max+1][j_max+1],u[i_max+1][j_max+1],v[i_max+1][j_max+1];
  float del_x,del_y,beta,err,err1,err2;
  del_x = del_y = 1.0/(i_max-1);
  beta = del_x/del_y;
  //************ Boundary Conditions**********//
   for(j=1;j<=j_max;j++)
                { z[1][j] = z[i_max][j] = 0.0;
                        }
        for(i=1;i<=i_max;i++)
                { z[i][1] = z[i][j_max] = 0.0;
                        }
  for(i=1;i<=i_max;i++){
    u[i][1] = 0.0;
    v[i][1] = 0.0;
    u[i][j_max] = U;
    v[i][j_max] = 0.0;}
  for(j=1;j<=j_max;j++){
    u[1][j] = 0.0;
    v[1][j] = 0.0;
    u[i_max][j] = 0.0;
    v[i_max][j] = 0.0;}
  //************* Initial Conditions ************//
  for(i=1;i<=i_max;i++){
      for(j=1;j<=j_max;j++){
        z[i][j] = 0.0;}}
  for(i=1;i<=i_max;i++){
  for(j=1;j<=j_max;j++){
        if(j==j_max)
        w[i][j]= -2*U/del_y;
//        printf("%Lf",w[i][j]);}
    else w[i][j] = 0.0; 
        }}
  err= 0.00002;
  err1=0.007;
  err2=0.008;
  while(err>err_max){
    err = 0.00000;
    err1=0.00,err2=0.00;
   for(i=2;i<=i_max-1;i++){
                        for(j=2;j<=j_max-1;j++){
                        w_fin[i][j] = w[i][j];
//      printf("%Lf",w[i][j]);
                }}


  for(i=2;i<=i_max-1;i++){
    for(j=2;j<=j_max-1;j++){
        z[i][j] = (z[i+1][j] + z[i-1][j] + beta*beta*(z[i][j+1] + z[i][j-1]) + del_x*del_x*w[i][j])/(2*(1+beta*beta));
          }
        }
   for(j=2;j<=j_max-1;j++)
                { w[1][j] = -2*z[2][j]/(del_x*del_x);
                  }
        for(j=2;j<=j_max-1;j++)
                { w[i_max][j] = -2*z[i_max-1][j]/(del_x*del_x);
                        }
        for(i=2;i<=i_max-1;i++)
                { w[i][1] = -2*z[i][2]/(del_y*del_y);
                        }
        for(i=2;i<=i_max-1;i++)
                { w[i][j_max] = -(2*z[i][j_max-1]+2*del_y*U)/(del_y*del_y);
                        }
  for(i=2;i<=i_max-1;i++){
    for(j=2;j<=j_max-1;j++){
      w[i][j] = (w[i+1][j]+w[i-1][j]+beta*beta*(w[i][j+1]+w[i][j-1])-0.25*beta*Re*(w[i+1][j]-w[i-1][j])*(z[i][j+1]-z[i][j-1])         +0.25*beta*Re*(w[i][j+1]-w[i][j-1])*(z[i+1][j]-z[i-1][j]))/(2*(1+beta*beta));
          }}
  for(i=2;i<=i_max-1;i++){
                for(j=2;j<=j_max-1;j++){
        err1 = err1+fabs(w_fin[i][j]-w[i][j]);
          }}
   for(i=2;i<=i_max-1;i++){
                for(j=2;j<=j_max-1;j++){
                                err2 = err2+fabs(w_fin[i][j]);
                                        }}
    err = err1/err2;
  }
  for(i=2;i<=i_max-1;i++){
    for(j=2;j<=j_max-1;j++){
        u[i][j] = (z[i][j+1]-z[i][j-1])/(2*del_y);
        v[i][j] = -(z[i+1][j]-z[i-1][j])/(2*del_x);}}
  pt = fopen("v_vel.dat","w+");
  for(i=1;i<=i_max;i++){
  fprintf(pt,"%f \t %Lf \n",(i-1)*del_x,v[i][(j_max+1)/2]);}
  pt = fopen("u_vel.dat","w+");
  for(j=1;j<=j_max;j++){
  fprintf(pt,"%f \t %Lf \n",(j-1)*del_y,u[(i_max+1)/2][j]);}  
  pt = fopen("contour.dat","w+");
  fprintf(pt,"variables=x,y,z\n");
    fprintf(pt,"zone T=\"\",i=%d,j=%d\n",i_max,j_max);
  for(i=1;i<=i_max;i++){
    for(j=1;j<=j_max;j++){
      fprintf(pt,"%f \t %f \t %Lf \n",(i-1)*del_x,(j-1)*del_y,z[i][j]);}}
  }
  
  
  
  