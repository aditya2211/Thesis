//Implementation of a natural cubic spline

#include <stdio.h>
#include <stdlib.h>

float* initialise(int n){
  float *a ;
  a =  (float*)malloc(n*sizeof(float));
  return a;
}
void cubic_spline(int n,float *x,float *y,float *a,float *b,float *c,float *d){
  //S(x) = Sj(x) = aj + bj(x - xj) + cj(x - xj)^2 + dj(x - xj)^3
  //Initialisation
  int i;
  for(int i = 0;i<=n-1;i++){
    a[i] = y[i];
  }
  
  float *h,*alpha,*l,*mu,*z;
  
  h = initialise(n);
  for(i=0;i<=n-1;i++){
    h[i] = x[i+1]-x[i];
  }

  alpha = initialise(n+1);
  for(i=1;i<=n-1;i++){
    alpha[i] = 3*(a[i+1]-a[i])/h[i] - 3*(a[i]-a[i-1])/h[i-1];
  }
  //Steps solving a tridiagonal linear system

  l = initialise(n+1);
  mu = initialise(n+1);
  z = initialise(n+1);
  l[0] = 1; mu[0] = 0; z[0] = 0;

  for(i=1;i<=n-1;i++){
    l[i] = 2.0*(x[i+1]-x[i-1]) - h[i-1]*mu[i-1];
    mu[i] = h[i]/l[i];
    z[i] = (alpha[i] - h[i-1]*z[i-1])/l[i];
  }
  l[n] = 1; z[n] = 0; c[n] = 0;

  for(i=n-1;i>=0;i--){
    c[i] = z[i] - mu[i]*c[i+1];
    b[i] = (a[i+1] - a[i])/h[i] - h[i]*(c[i+1]+2*c[i])/3.0;
    d[i] = (c[i+1]-c[i])/(3*h[i]);
  }


}

int main(int argc, char *argv[]){

  float *x,*y,*a,*b,*c,*d;
  int n = 3;
  n = n-1;
  x = initialise(n+1);
  y = initialise(n+1);

  a = initialise(n);
  b = initialise(n);
  c = initialise(n+1);
  d = initialise(n);

  x[0] = 1;
  x[1] = 2;
  x[2] = 3;
  y[0] = 3.5;
  y[1] = 2.4;
  y[2] = 3;
  cubic_spline(n,x,y,a,b,c,d);
  for(int i = 0;i<n;i++){
    printf("%d:%f %f %f %f ",i,a[i],b[i],c[i],d[i]);
  }
  return 0;
}