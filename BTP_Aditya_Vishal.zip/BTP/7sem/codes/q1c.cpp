#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <iomanip>
using namespace std;

double func(double x) { return 200*x*(x-4);}


int solve (double dx, double dy, int nox, int noy, double x, double y, double tol, int max_it, double w)
{
   ofstream out; 
   int i,j,k,N = max_it,l=1;
   double lambda,grid[nox+1][noy+1],mu,z,norm=0;

   lambda = dx*dx/(dy*dy);
   mu = 2*(1+lambda);
   
   for(j=0;j<=nox;j++) {grid[j][0] = func(j*dx);grid[j][noy]=0;}
   for(j=1;j<=noy;j++) grid[0][j]=grid[nox][j] = 0;
   for(i=1;i<nox;i++)
     for (j=1;j<noy;j++) grid[i][j] =0;
    
     
   while(l<N)
    {
       norm=0;
       for(j=noy-1;j>=1;j--)
        { 
         for(i=1;i<=nox-1;i++)
              {  z = grid[i][j] + w*(lambda*grid[i][j+1] + grid[i-1][j] + grid[i+1][j] + lambda*grid[i][j-1] - mu*grid[i][j])/mu;
                 if(abs(grid[i][j] - z) > norm) norm = abs(grid[i][j] -z);
                   grid[i][j] = z;
               }
         } 
  
     
     if(norm < tol) break;       
     else l++;  
    
 } 


 return l;
}





int main()
{
	double deltax[3] = {.1,.05,.025},dx,dy,tol=.00001,x=4,y=1,lambda,beta[3] = {1,.5,2};
	int nox,noy,N=10000,i,j,q;

	for(i=0;i<3;i++)
 	 for( j=0;j<3;j++)
	 {
		dx = deltax[j]; dy = dx/beta[i];
		
		nox = ceil((double)x/(double)dx);
		noy = ceil((double)y/(double)dy);

		lambda = dx*dx/(dy*dy);

		string s = "w_opt";
		ofstream out;
		stringstream stream1,stream2;

		stream1 << fixed << setprecision(3) << dx;
		stream2 << fixed << setprecision(3) << beta[i];
		
		s=s+ "x="+ stream1.str() + "beta="+stream2.str()+".txt";
		const char* outfile;
		out.open(outfile);
		double k = (cos(M_PI/(nox+1)) + lambda*cos(M_PI/(noy+1)))/(1+lambda);
		out<<"Optimal omega is : "<< (double)2*((double)1 - sqrt((double)1-k*k))/((double)k*k) << endl;
		for (q = 0;q<20;q++) 
			out<<(double)1+(double)q*.05<<" "<< solve (dx,dy,nox,noy,x,y,tol,N,(double)1+(double)q*.05)<<endl;
		
		out.close();}
	return 1;
}
