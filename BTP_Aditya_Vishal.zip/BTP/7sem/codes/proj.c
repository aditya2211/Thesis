/*file:proj.c : driven cavity problem using streamfunction-velocity formulation*/
/*2nd order formulation both at the interior and vorticity BC*/
/*started on 12th Oct, 2004, Gauss-Siedel as the iterative solver*/
#include<stdio.h>
#include<math.h>
#define m 41
#define n 41
#define re 100
#define h 1/((float) (m-1))
#define pi 4*atan(1.0)
main()
{
		 /*DECLARATION SECTION*/
  FILE *pt,*pt2,*pt1;
  int i,j,it=0,it1=0,it2=0,tag;
  double u[m+5][n+5],v[m+5][n+5],l1=1.0,l2=0.3;
  double max(),ii,jj;
  double xn[m+5][n+5],xx[m+5][n+5],w[m+5][n+5],err=.5e-4;
  double wn[m+5][n+5],wm[m+5][n+5];
  double err1=1.0e-4,norm(),vecmul(),e[m+5][n+5],e1[m+5][n+5],e2[m+5][n+5],xm[m+5][n+5];
  double nn,mu,ta,xx1,yy1,xx2,yy2,k,val();

		  /*INITIALIZATION*/

  for(j=1;j<n-1;j++)
   {
	u[0][j]=v[0][j]=0;
	u[m-1][j]=v[m-1][j]=0;
   }

  for(i=0;i<m;i++)
   {
	u[i][n-1]=1;
	u[i][0]=v[i][0]=v[i][n-1]=0; 
   }

	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u[i][j]=v[i][j]=0.000;

  for(j=0;j<n;j++)
	  {
			xx[0][j]=xn[0][j]=0.00;
			xx[m-1][j]=xn[m-1][j]=0.00;
	  }


	
     for(i=1;i<m-1;i++)
	{
	  xx[i][0]=xn[i][0]=0.00;
	  xx[i][n-1]=xn[i][n-1]=0.00;
	}
  
	for(j=0;j<n;j++)for(i=0;i<m;i++)
          {
            xx[i][j]=xn[i][j]=0.00;
            w[i][j]=wn[i][j]=wm[i][j]=-2*j*h*h;
          }

        w[0][0]=w[m-1][0]=0.0;w[0][n-1]=w[m-1][n-1]=-(m-1);

  /*pt2=fopen("tmp4.dat","r+");
  for(j=0;j<n;j++)for(i=0;i<m;i++)
	fscanf(pt2,"%lf %lf %lf %lf %lf %lf",&ii,&jj,&u[i][j],&v[i][j],&xx[i][j],&w[i][j]);
	for(j=0;j<n;j++)for(i=0;i<m;i++)xn[i][j]=xm[i][j]=xx[i][j];
  fclose(pt2);*/
do
 {

	tag=1;it++;

  it1=0;
   do 
     {
     it1++;
     for(j=0;j<n;j++)for(i=0;i<m;i++)xn[i][j]=xx[i][j];
	

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         xx[i][j]=0.25*(xx[i+1][j]+xx[i-1][j]+xx[i][j+1]+xx[i][j-1]+h*h*w[i][j]);
         xx[i][j]=xn[i][j]+l1*(xx[i][j]-xn[i][j]);

         }

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)e[i][j]=xn[i][j]-xx[i][j];


}while(max(e)>0.0001);
                 /* Calculation of u and v*/

	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         u[i][j]=0.5*(m-1)*(xx[i][j+1]-xx[i][j-1]);
         v[i][j]=0.5*(m-1)*(xx[i-1][j]-xx[i+1][j]);
         }




        for(j=1;j<n-1;j++){w[0][j]=-2*xx[1][j]/(h*h);w[m-1][j]=-2*xx[m-2][j]/(h*h);}
        for(i=1;i<m-1;i++){w[i][0]=-2*xx[i][1]/(h*h);w[i][n-1]=-2*(h+xx[i][n-2])/(h*h);}


  it2=0;
do
  {
     it2++;
     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)wn[i][j]=w[i][j];
	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
         {
         w[i][j]=0.125*((2-re*h*u[i][j])*w[i+1][j]+(re*h*u[i][j]+2)*w[i-1][j]+(2-re*h*v[i][j])*w[i][j+1]+(re*h*v[i][j]+2)*w[i][j-1]);
         w[i][j]=wn[i][j]+l2*(w[i][j]-wn[i][j]);
         }

     for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)e[i][j]=w[i][j]-wn[i][j];

}while(max(e)>0.0001);


     for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
           e1[i][j]=w[i][j]-wm[i][j];
          w[i][j]=wm[i][j]+0.05*(w[i][j]-wm[i][j]);
        }
     for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
          e2[i][j]=xx[i][j]-xm[i][j]; 
          xx[i][j]=xm[i][j]+1.0*(xx[i][j]-xm[i][j]);
        }
     for(j=0;j<n;j++)for(i=0;i<m;i++)wm[i][j]=w[i][j];
     for(j=0;j<n;j++)for(i=0;i<m;i++)xm[i][j]=xx[i][j];


		 printf("%d %d %d %lf %lf %e\n",it,it1,it2,u[10][10],max(xx),max(e1));

		 /*if(((int) it/4)*4==it)
	           {  pt=fopen("dct.dat","w+");
	  fprintf(pt,"variables=x,y,u,v,s,w\n");
	  fprintf(pt,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n;j++) for(i=0;i<m;i++)
		{
 fprintf(pt,"%lf %lf %e %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j],w[i][j]);

		}
	         fclose(pt);
		   }*/
		 

	 /*if(norm(f1)/((float) (m-1))<err1)tag=0;*/
	 if(max(e1)<err1)tag=0;
	 /*if(it1>3800)break;*/

}while(tag==1);

		 pt1=fopen("dct_100.dat","w+");
	  fprintf(pt1,"variables=x,y,u,v,s,w\n");
	  fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n;j++) for(i=0;i<m;i++)
		{
 fprintf(pt1,"%lf %lf %e %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j],w[i][j]);

		}
		fclose(pt1);

		 }

 

  double norm(s)
  double s[][n+5];
  {
    int i,j;
    double x2n=0.0;

    for(j=0;j<n;j++)for(i=0;i<m;i++)  x2n += s[i][j]*s[i][j];
    x2n=sqrt(x2n);
    return(x2n);

  }

  double vecmul(v,s)
  double v[][n+5],s[][n+5];
  {
   int i,j;
   double r=0.0;
   for(j=0;j<n;j++)for(i=0;i<m;i++)  r += v[i][j]*s[i][j];
   return(r);
  }
 double max(double s[][n+5])
     {
	int i,j;
        double v=fabs(s[0][0]);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         if(fabs(s[i][j])>=v)  v=fabs(s[i][j]);
         else v=v;
       }
         return(v);

     }
