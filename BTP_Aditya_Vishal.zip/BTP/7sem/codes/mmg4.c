/*file:mmg4.c : driven cavity problem using streamfunction-velocity formulation*/
/*fourth order biharmonic formulation and fourth order velocity*/
/*started on 18th July, 2005, BiGGStab as the iterative solver*/
#include<stdio.h>
#include<math.h>
#define m 257
#define n 257
#define re 100
#define h 1/((double) (m-1))
#define pi 4*atan(1.0)
main()
{
		 /*DECLARATION SECTION*/
  FILE *pt,*pt2,*pt1;
  int i,j,ite,it1=0,tag;
  double u[m+5][n+5],v[m+5][n+5];
  double max(),bb[m+5][n+5],f[m+5][n+5];
  double at1[m+5][n+5],bt1[m+5][n+5],
         ct1[m+5][n+5],ct2[m+5][n+5],dt1[m+5][n+5],dt2[m+5][n+5];
  double bb1[m+5][n+5],xn[m+5][n+5],bn[m+5][n+5],xx[m+5][n+5],r[m+5][n+5],
			b[m+5][n+5],p[m+5][n+5],w[m+5][n+5],a1,b1,err=0.5e-6;
  double v1[m+5][n+5],t2[m+5][n+5],s[m+5][n+5],r1[m+5][n+5],w1,w2,l1=0.900;
  double cu2,cu8,cv4,cv6;
  double err1=0.5e-6,norm(),vecmul(),e1[m+5][n+5],f1[m+5][n+5],xm[m+5][n+5];
  double nn,mu,ta,xx1,yy1,xx2,yy2,k,val(),r0,rn,ii,jj;
  void matmul();

		  /*INITIALIZATION*/

  for(j=1;j<n-1;j++)
   {
	u[0][j]=v[0][j]=0;
	u[m-1][j]=v[m-1][j]=0;
   }

  for(i=0;i<m;i++)
   {
	u[i][n-1]=1;
	u[i][0]=v[i][0]=v[i][n-1]=0; 
   }

	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u[i][j]=v[i][j]=0.000;

  for(j=0;j<n;j++)
	  {
			xx[0][j]=xn[0][j]=bb1[0][j]=0.00;
			xx[m-1][j]=xn[m-1][j]=bb1[m-1][j]=0.00;
	  }


	
     for(i=1;i<m-1;i++)
	{
	  xx[i][0]=xn[i][0]=bb1[i][0]=0.00;
	  xx[i][n-1]=xn[i][n-1]=bb1[i][n-1]=0.00;
	}
	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++){xx[i][j]=xn[i][j]=0.00;}

  /*pt2=fopen("tmp.dat","r+");
  for(j=0;j<n;j++)for(i=0;i<m;i++)
	fscanf(pt2,"%lf %lf %lf %lf %lf",&ii,&jj,&u[i][j],&v[i][j],&xx[i][j]);
	for(j=0;j<n;j++)for(i=0;i<m;i++)xn[i][j]=xx[i][j];
  fclose(pt2);*/
do
 {

	tag=1;it1++;

for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
          {
                 bb1[i][j]=112*h*(u[i][j-1]-v[i-1][j]+v[i+1][j]-u[i][j+1]);
                 bb1[i][j]+=4*h*(u[i-1][j-1]+u[i+1][j-1]-v[i-1][j-1]-v[i-1][j+1]+v[i+1][j+1]+v[i+1][j-1]-u[i-1][j+1]-u[i+1][j+1]);
                 /*bb1[i][j]+=26*re*h*h*(v[i][j]*(u[i+1][j]+u[i-1][j])-u[i][j]*(v[i][j+1]+v[i][j-1]));*/
                 bb1[i][j]+=13*re*h*(u[i][j]*(xx[i+1][j+1]+xx[i+1][j-1]-xx[i-1][j+1]-xx[i-1][j-1])+v[i][j]*(xx[i+1][j+1]+xx[i-1][j+1]-xx[i+1][j-1]-xx[i-1][j-1]));
                 bb1[i][j]+=12*re*h*h*(v[i][j]*(u[i][j+1]+u[i][j-1])-u[i][j]*(v[i+1][j]+v[i-1][j]));
                 bb1[i][j]+=re*h*h*(u[i][j]*(v[i+1][j+1]+v[i+1][j-1]+v[i-1][j+1]+v[i-1][j-1])-v[i][j]*(u[i+1][j+1]+u[i-1][j+1]+u[i+1][j-1]+u[i-1][j-1]));
                 bb1[i][j]+=re*h*h*(u[i][j]*(-u[i+1][j+1]+u[i+1][j-1]+u[i-1][j+1]-u[i-1][j-1])-v[i][j]*(-v[i+1][j+1]+v[i-1][j+1]+v[i+1][j-1]-v[i-1][j-1]));
          }


     /*BEGINING OF BICONJUGATE GRADIENT*/
	  matmul(xx,r);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
               {				       
		   r1[i][j] = r[i][j] = bb1[i][j] - r[i][j];
		   v1[i][j]=p[i][j]=0;
	       }
	             ite=0;
		     r0=a1=w1=1;
		     while(norm(r) > err)/*loop for iteration begins*/
		     {
			     ite++;
			     r0=-w1*r0;
			     rn=vecmul(r,r1);
			     b1=(rn)*(a1)/r0;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
			     {
				     xm[i][j]=xx[i][j];
				     p[i][j]=r[i][j]-b1*(p[i][j]-w1*v1[i][j]);
			     }
       matmul(p,v1);
			     a1=rn/vecmul(r1,v1);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
				     s[i][j] =r[i][j]- a1*v1[i][j];
			     r0=rn;
       matmul(s,t2);
			     w1=vecmul(t2,s)/vecmul(t2,t2);
			     if(rn==0)break;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
		{
		     xx[i][j]+=a1*p[i][j]+w1*s[i][j];r[i][j]=s[i][j]-w1*t2[i][j];
		     xx[i][j]=xm[i][j]+l1*(xx[i][j]-xm[i][j]);
			     }
			     
		
		     }
		     /*END OF BICONJUGATE GRADIENT*/

     for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         e1[i][j]=xx[i][j]-xn[i][j];xx[i][j]=xn[i][j]+l1*e1[i][j];
	 xn[i][j]=xx[i][j];
       }


                 /* Calculation of u*/

   for(i=1;i<m-1;i++)
    {
     ct1[i][1]=ct2[i][1]=3*(m-1)*(xx[i][2]-xx[i][0])-u[i][0];
     ct1[i][n-2]=ct2[i][n-2]=3*(m-1)*(xx[i][n-1]-xx[i][n-3])-u[i][n-1];

     for(j=2;j<n-2;j++)ct1[i][j]=3*(m-1)*(xx[i][j+1]-xx[i][j-1]);

     for(j=1;j<n-1;j++)
    {bt1[i][j]=at1[i][j]=1;dt1[i][j]=dt2[i][j]=4;}
   bt1[i][1]=0;at1[i][n-2]=0;

   for(j=2;j<n-1;j++)dt2[i][j]=dt1[i][j]-(bt1[i][j]*at1[i][j-1])/(dt2[i][j-1]);
   for(j=2;j<n-1;j++)ct2[i][j]=ct1[i][j]-(ct2[i][j-1]*bt1[i][j])/(dt2[i][j-1]);
   u[i][n-2]=ct2[i][n-2]/dt2[i][n-2];
   for(j=n-3;j>0;j--)u[i][j]=(ct2[i][j]-at1[i][j]*u[i][j+1])/dt2[i][j];

    }


              /* Calculation of v*/

   for(j=1;j<n-1;j++)
    {
     ct1[1][j]=ct2[1][j]=3*(m-1)*(xx[0][j]-xx[2][j])-v[0][j];
     ct1[m-2][j]=ct2[m-2][j]=3*(m-1)*(xx[m-3][j]-xx[m-1][j])-v[m-1][j];

     for(i=2;i<m-2;i++)ct1[i][j]=3*(m-1)*(xx[i-1][j]-xx[i+1][j]);

     for(i=1;i<m-1;i++)
    {bt1[i][j]=at1[i][j]=1;dt1[i][j]=dt2[i][j]=4;}
   bt1[1][j]=0;at1[m-2][j]=0;

   for(i=2;i<m-1;i++)dt2[i][j]=dt1[i][j]-(bt1[i][j]*at1[i-1][j])/(dt2[i-1][j]);
   for(i=2;i<m-1;i++)ct2[i][j]=ct1[i][j]-(ct2[i-1][j]*bt1[i][j])/(dt2[i-1][j]);
   v[m-2][j]=ct2[m-2][j]/dt2[m-2][j];
   for(i=m-3;i>0;i--)v[i][j]=(ct2[i][j]-at1[i][j]*v[i+1][j])/dt2[i][j];

    }


		 printf("%d %d %lf %e\n",it1,ite,max(xx),max(e1));

		 if(((int) it1/10)*10==it1)
	           {  
	           pt2=fopen("dct11.dat","w+");
		for(j=0;j<n;j++) 
                  {fprintf(pt2,"\n");
              for(i=0;i<m;i++)
		{
 fprintf(pt2,"%lf %lf %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j]);

		}}
	         fclose(pt2);
		   }
		 

	 /*if(norm(f1)/((double) (m-1))<err1)tag=0;*/
	 if(max(e1)<err1)tag=0;
	 /*if(it1>3800)break;*/

}while(tag==1);

		 pt1=fopen("dctty.dat","w+");
	  fprintf(pt1,"variables=x,y,u,v,s\n");
	  fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n;j++) for(i=0;i<m;i++)
		{
 fprintf(pt1,"%lf %lf %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j]);

		}
		fclose(pt1);

		 }
 void matmul(double t[][n+5],double at[][n+5]) 
  {
	int i,j;
	double c1,c2,c3,c4,c5,c6,c7,c8,c9;


	for(i=0;i<m;i++)
	  {
		at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
	  }


	for(j=1;j<n-1;j++)
	  {
		at[0][j]=t[0][j]; at[m-1][j]=t[m-1][j];

	  }


	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
	  {
                 at[i][j]=24*t[i-1][j-1]-288*t[i][j-1]+24*t[i+1][j-1];
                 at[i][j]+=-288*t[i-1][j]+1056*t[i][j]-288*t[i+1][j];
                 at[i][j]+=24*t[i-1][j+1]-288*t[i][j+1]+24*t[i+1][j+1];
                 /*at[i][j]=(m-1)*(m-1)*at[i][j];*/
	  }


 }

 

  double norm(s)
  double s[][n+5];
  {
    int i,j;
    double x2n=0.0;

    for(j=0;j<n;j++)for(i=0;i<m;i++)  x2n += s[i][j]*s[i][j];
    x2n=sqrt(x2n);
    return(x2n);

  }

  double vecmul(v,s)
  double v[][n+5],s[][n+5];
  {
   int i,j;
   double r=0.0;
   for(j=0;j<n;j++)for(i=0;i<m;i++)  r += v[i][j]*s[i][j];
   return(r);
  }
 double max(double s[][n+5])
     {
	int i,j;
        double v=fabs(s[0][0]);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         if(fabs(s[i][j])>=v)  v=fabs(s[i][j]);
         else v=v;
       }
         return(v);

     }
