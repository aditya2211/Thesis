#include "myclock.h"
#include <sys/time.h>

double myclock_starttime, myclock_stoptime;
struct timeval myclock_tv;

void clock_start(void)
{	gettimeofday(&myclock_tv,0);
	myclock_starttime = (double)myclock_tv.tv_sec +
				(double)myclock_tv.tv_usec / 1000000.0;
}

double clock_stop(void)
{	gettimeofday(&myclock_tv,0);
	myclock_stoptime = (double)myclock_tv.tv_sec +
				(double)myclock_tv.tv_usec / 1000000.0;

	return( myclock_stoptime - myclock_starttime );
}











