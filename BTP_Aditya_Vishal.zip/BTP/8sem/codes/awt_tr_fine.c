/*file:awt_tr.c : driven cavity problem using transient streamfunction-velocity formulation*/
/*Weighted time average*/
/*second order biharmonic formulation and fourth order velocity*/
/*started on 20th Jan, 2005, BiGGStab as the iterative solver*/
#include <stdio.h>
#include <math.h>
#define m 41
#define n 41
#define re 100
#define dt 0.01
#define h_f 1/((float) (m-1))
#define pi 4*atan(1.0)
main()
{
		 /*DECLARATION SECTION*/
  FILE *pt,*pt2,*pt1;
  int i,j,ite,it1=0,tag;
  double u_fine[m+5][n+5],v_fine[m+5][n+5],u1_fine[m+5][n+5],v11_fine[m+5][n+5];
  double max(),bb_fine[m+5][n+5],t=00.00;
  double at1_fine[m+5][n+5],bt1_fine[m+5][n+5],
         ct1_fine[m+5][n+5],ct2_fine[m+5][n+5],dt1_fine[m+5][n+5],dt2_fine[m+5][n+5];
  double bb1_fine[m+5][n+5],xn_fine[m+5][n+5],xx_fine[m+5][n+5],r_fine[m+5][n+5],
			b_fine[m+5][n+5],p_fine[m+5][n+5],w_fine[m+5][n+5],a1,b1,err=0.5e-9;
  double v1_fine[m+5][n+5],t2_fine[m+5][n+5],s_fine[m+5][n+5],r1_fine[m+5][n+5],w1,w2,l1;
  double cu2,cu8,cv4,cv6;
  double err1=0.5e-9,norm(),vecmul_fine(),e1_fine[m+5][n+5],f1_fine[m+5][n+5];
  double nn,mu,ta,xx1,yy1,xx2,yy2,k,val(),r0,rn,ii,jj;
  void matmul_fine(),mat1_fine();

		  /*INITIALIZATION*/
  t = 0.0;
  for(j=1;j<n-1;j++)
   {
	u_fine[0][j]=v_fine[0][j]=u1_fine[0][j]=v11_fine[0][j]=0;
	u_fine[m-1][j]=v_fine[m-1][j]=u1_fine[m-1][j]=v11_fine[m-1][j]=0;
   }

  for(i=0;i<m;i++)
   {
	u_fine[i][n-1]=u1_fine[i][n-1]=1;
	u_fine[i][0]=v_fine[i][0]=v_fine[i][n-1]=u1_fine[i][0]=v11_fine[i][0]=v11_fine[i][n-1]=0; 
   }

	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u_fine[i][j]=v_fine[i][j]=u1_fine[i][j]=v11_fine[i][j]=0.000;

  for(j=0;j<n;j++)
	  {
			xx_fine[0][j]=xn_fine[0][j]=bb1_fine[0][j]=0.00;
			xx_fine[m-1][j]=xn_fine[m-1][j]=bb1_fine[m-1][j]=0.00;
	  }


	
     for(i=1;i<m-1;i++)
	{
	  xx_fine[i][0]=xn_fine[i][0]=bb1_fine[i][0]=0.00;
	  xx_fine[i][n-1]=xn_fine[i][n-1]=bb1_fine[i][n-1]=0.00;
	}
	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++){xx_fine[i][j]=xn_fine[i][j]=0.00;}

  /*pt2=fopen("tmp.dat","r+");
  for(j=0;j<n;j++)for(i=0;i<m;i++)
	fscanf(pt2,"%lf %lf %lf %lf %lf",&ii,&jj,&u_fine[i][j],&v_fine[i][j],&xx_fine[i][j]);
	for(j=0;j<n;j++)for(i=0;i<m;i++)
	  {
	
	  	  xn_fine[i][j]=xx_fine[i][j];u1_fine[i][j]=u_fine[i][j];v11_fine[i][j]=v_fine[i][j];
          }		  
  fclose(pt2);
*/

do
 {

	tag=1;t+=dt;it1++;



	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
	  {
		 bb1_fine[i][j]=-3*(m-1)*(u_fine[i][j-1]-v_fine[i-1][j]+v_fine[i+1][j]-u_fine[i][j+1])/re;
		 bb1_fine[i][j]+=0.5*u_fine[i][j]*(v_fine[i][j-1]+v_fine[i][j+1]+v_fine[i-1][j]+v_fine[i+1][j]);
		 bb1_fine[i][j]+=-0.5*v_fine[i][j]*(u_fine[i][j-1]+u_fine[i][j+1]+u_fine[i-1][j]+u_fine[i+1][j]);
		 bb1_fine[i][j]=dt*bb1_fine[i][j]+dt*(m-1)*(m-1)*(xn_fine[i-1][j-1]-8*xn_fine[i][j-1]+xn_fine[i+1][j-1]-8*xn_fine[i-1][j]+28*xn_fine[i][j]-8*xn_fine[i+1][j]+xn_fine[i-1][j+1]-8*xn_fine[i][j+1]+xn_fine[i+1][j+1])/re;
		 bb1_fine[i][j]+=0.5*(xn_fine[i][j-1]+xn_fine[i-1][j]+xn_fine[i+1][j]+xn_fine[i][j+1]-4*xn_fine[i][j]);
	  }

     /*BEGINING OF BICONJUGATE GRADIENT*/
	  mat1_fine(xx_fine,r_fine);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
               {				       
		   r1_fine[i][j] = r_fine[i][j] = bb1_fine[i][j] - r_fine[i][j];
		   v1_fine[i][j]=p_fine[i][j]=0;
	       }
	             ite=0;
		     r0=a1=w1=1;
		     while(norm(r_fine) > err)/*loop for iteration begins*/
		     {
			     ite++;
			     r0=-w1*r0;
			     rn=vecmul_fine(r_fine,r1_fine);
			     b1=(rn)*(a1)/r0;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
			     {
				     at1_fine[i][j]=xx_fine[i][j];
				     p_fine[i][j]=r_fine[i][j]-b1*(p_fine[i][j]-w1*v1_fine[i][j]);
			     }
       mat1_fine(p_fine,v1_fine);
			     a1=rn/vecmul_fine(r1_fine,v1_fine);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
				     s_fine[i][j] =r_fine[i][j]- a1*v1_fine[i][j];
			     r0=rn;
       mat1_fine(s_fine,t2_fine);
			     w1=vecmul_fine(t2_fine,s_fine)/vecmul_fine(t2_fine,t2_fine);
			     if(rn==0)break;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
		{
		     xx_fine[i][j]+=a1*p_fine[i][j]+w1*s_fine[i][j];r_fine[i][j]=s_fine[i][j]-w1*t2_fine[i][j];
		     xx_fine[i][j]=at1_fine[i][j]+0.65*(xx_fine[i][j]-at1_fine[i][j]);
			     }
			     
		
		     }
		     /*END OF BICONJUGATE GRADIENT*/



                 /* Calculation of u1*/

   for(i=1;i<m-1;i++)
    {
     ct1_fine[i][1]=ct2_fine[i][1]=3*(m-1)*(xx_fine[i][2]-xx_fine[i][0])-u1_fine[i][0];
     ct1_fine[i][n-2]=ct2_fine[i][n-2]=3*(m-1)*(xx_fine[i][n-1]-xx_fine[i][n-3])-u1_fine[i][n-1];

     for(j=2;j<n-2;j++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i][j+1]-xx_fine[i][j-1]);

     for(j=1;j<n-1;j++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[i][1]=0;at1_fine[i][n-2]=0;

   for(j=2;j<n-1;j++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i][j-1])/(dt2_fine[i][j-1]);
   for(j=2;j<n-1;j++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i][j-1]*bt1_fine[i][j])/(dt2_fine[i][j-1]);
   u1_fine[i][n-2]=ct2_fine[i][n-2]/dt2_fine[i][n-2];
   for(j=n-3;j>0;j--)u1_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*u1_fine[i][j+1])/dt2_fine[i][j];

    }


              /* Calculation of v11*/

   for(j=1;j<n-1;j++)
    {
     ct1_fine[1][j]=ct2_fine[1][j]=3*(m-1)*(xx_fine[0][j]-xx_fine[2][j])-v11_fine[0][j];
     ct1_fine[m-2][j]=ct2_fine[m-2][j]=3*(m-1)*(xx_fine[m-3][j]-xx_fine[m-1][j])-v11_fine[m-1][j];

     for(i=2;i<m-2;i++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i-1][j]-xx_fine[i+1][j]);

     for(i=1;i<m-1;i++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[1][j]=0;at1_fine[m-2][j]=0;

   for(i=2;i<m-1;i++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i-1][j])/(dt2_fine[i-1][j]);
   for(i=2;i<m-1;i++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i-1][j]*bt1_fine[i][j])/(dt2_fine[i-1][j]);
   v11_fine[m-2][j]=ct2_fine[m-2][j]/dt2_fine[m-2][j];
   for(i=m-3;i>0;i--)v11_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*v11_fine[i+1][j])/dt2_fine[i][j];

    }



	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
	  {
		 bb1_fine[i][j]=-3*(m-1)*(u1_fine[i][j-1]-v11_fine[i-1][j]+v11_fine[i+1][j]-u1_fine[i][j+1])/re;
		 bb1_fine[i][j]+=0.5*u1_fine[i][j]*(v11_fine[i][j-1]+v11_fine[i][j+1]+v11_fine[i-1][j]+v11_fine[i+1][j]);
		 bb1_fine[i][j]+=-0.5*v11_fine[i][j]*(u1_fine[i][j-1]+u1_fine[i][j+1]+u1_fine[i-1][j]+u1_fine[i+1][j]);
		 bb1_fine[i][j]+=-3*(m-1)*(u_fine[i][j-1]-v_fine[i-1][j]+v_fine[i+1][j]-u_fine[i][j+1])/re;
		 bb1_fine[i][j]+=0.5*u_fine[i][j]*(v_fine[i][j-1]+v_fine[i][j+1]+v_fine[i-1][j]+v_fine[i+1][j]);
		 bb1_fine[i][j]+=-0.5*v_fine[i][j]*(u_fine[i][j-1]+u_fine[i][j+1]+u_fine[i-1][j]+u_fine[i+1][j]);
		 bb1_fine[i][j]=0.5*dt*bb1_fine[i][j]+0.5*dt*(m-1)*(m-1)*(xn_fine[i-1][j-1]-8*xn_fine[i][j-1]+xn_fine[i+1][j-1]-8*xn_fine[i-1][j]+28*xn_fine[i][j]-8*xn_fine[i+1][j]+xn_fine[i-1][j+1]-8*xn_fine[i][j+1]+xn_fine[i+1][j+1])/re;
		 bb1_fine[i][j]+=0.5*(xn_fine[i][j-1]+xn_fine[i-1][j]+xn_fine[i+1][j]+xn_fine[i][j+1]-4*xn_fine[i][j]);
	  }

     /*BEGINING OF BICONJUGATE GRADIENT*/
	  matmul_fine(xx_fine,r_fine);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
               {				       
		   r1_fine[i][j] = r_fine[i][j] = bb1_fine[i][j] - r_fine[i][j];
		   v1_fine[i][j]=p_fine[i][j]=0;
	       }
	             ite=0;
		     r0=a1=w1=1;
		     while(norm(r_fine) > err)/*loop for iteration begins*/
		     {
			     ite++;
			     r0=-w1*r0;
			     rn=vecmul_fine(r_fine,r1_fine);
			     b1=(rn)*(a1)/r0;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
			     {
				     at1_fine[i][j]=xx_fine[i][j];
				     p_fine[i][j]=r_fine[i][j]-b1*(p_fine[i][j]-w1*v1_fine[i][j]);
			     }
       matmul_fine(p_fine,v1_fine);
			     a1=rn/vecmul_fine(r1_fine,v1_fine);
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
				     s_fine[i][j] =r_fine[i][j]- a1*v1_fine[i][j];
			     r0=rn;
       matmul_fine(s_fine,t2_fine);
			     w1=vecmul_fine(t2_fine,s_fine)/vecmul_fine(t2_fine,t2_fine);
			     if(rn==0)break;
	      for(j=0;j<n;j++)for(i=0;i<m;i++)
		{
		     xx_fine[i][j]+=a1*p_fine[i][j]+w1*s_fine[i][j];r_fine[i][j]=s_fine[i][j]-w1*t2_fine[i][j];
		     xx_fine[i][j]=at1_fine[i][j]+0.65*(xx_fine[i][j]-at1_fine[i][j]);
			     }
			     
		
		     }
		     /*END OF BICONJUGATE GRADIENT*/

     l1=0.90;
     for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         e1_fine[i][j]=xx_fine[i][j]-xn_fine[i][j];/*xx_fine[i][j]=xn_fine[i][j]+l1*e1_fine[i][j];*/
	 xn_fine[i][j]=xx_fine[i][j];
       }


                 /* Calculation of u*/

   for(i=1;i<m-1;i++)
    {
     ct1_fine[i][1]=ct2_fine[i][1]=3*(m-1)*(xx_fine[i][2]-xx_fine[i][0])-u_fine[i][0];
     ct1_fine[i][n-2]=ct2_fine[i][n-2]=3*(m-1)*(xx_fine[i][n-1]-xx_fine[i][n-3])-u_fine[i][n-1];

     for(j=2;j<n-2;j++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i][j+1]-xx_fine[i][j-1]);

     for(j=1;j<n-1;j++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[i][1]=0;at1_fine[i][n-2]=0;

   for(j=2;j<n-1;j++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i][j-1])/(dt2_fine[i][j-1]);
   for(j=2;j<n-1;j++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i][j-1]*bt1_fine[i][j])/(dt2_fine[i][j-1]);
   u_fine[i][n-2]=ct2_fine[i][n-2]/dt2_fine[i][n-2];
   for(j=n-3;j>0;j--)u_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*u_fine[i][j+1])/dt2_fine[i][j];

    }


              /* Calculation of v*/

   for(j=1;j<n-1;j++)
    {
     ct1_fine[1][j]=ct2_fine[1][j]=3*(m-1)*(xx_fine[0][j]-xx_fine[2][j])-v_fine[0][j];
     ct1_fine[m-2][j]=ct2_fine[m-2][j]=3*(m-1)*(xx_fine[m-3][j]-xx_fine[m-1][j])-v_fine[m-1][j];

     for(i=2;i<m-2;i++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i-1][j]-xx_fine[i+1][j]);

     for(i=1;i<m-1;i++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[1][j]=0;at1_fine[m-2][j]=0;

   for(i=2;i<m-1;i++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i-1][j])/(dt2_fine[i-1][j]);
   for(i=2;i<m-1;i++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i-1][j]*bt1_fine[i][j])/(dt2_fine[i-1][j]);
   v_fine[m-2][j]=ct2_fine[m-2][j]/dt2_fine[m-2][j];
   for(i=m-3;i>0;i--)v_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*v_fine[i+1][j])/dt2_fine[i][j];

    }


		 printf("%lf %lf %lf %lf %e\n",t,u_fine[20][30],v_fine[20][30],max(xx_fine),max(e1_fine));
/*
                 pt1=fopen("history_uv_fine.dat","a");
		 fprintf(pt1,"%lf %lf %lf\n",t,u_fine[32][40],v_fine[32][40]);
                 fclose(pt1);
		 if(((int) it1/10)*10==it1)
	           {  pt2=fopen("dct_Crit_fine.dat","w+");
                  fprintf(pt2,"time=%lf\n",t);
		    for(j=0;j<n;j++) 
		    {
			    //fprintf(pt2,"\n");
			    for(i=0;i<m;i++)		        fprintf(pt2,"%lf %lf %e %e %e\n",i*h_f,j*h_f,u_fine[i][j],v_fine[i][j],xx_fine[i][j]); 
		   }
	         fclose(pt2);
		   }
*/		 

	 /*if(norm(f1)/((float) (m-1))<err1)tag=0;*/
	 if(max(e1_fine)<err1)tag=0;
	 /*if(it1>6800)break;*/

}
//while(t<1000.00);
while(tag==1);

		 pt1=fopen("dct_fine.dat","w+");
	  fprintf(pt1,"variables=x,y,u,v,s\n");
	  fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
		for(j=0;j<n;j++) for(i=0;i<m;i++)
		{
 fprintf(pt1,"%lf %lf %e %e %e\n",i*h_f,j*h_f,u_fine[i][j],v_fine[i][j],xx_fine[i][j]);

		}
		fclose(pt1);

		 }

 void mat1_fine(double t[][n+5],double at[][n+5]) 
  {
	int i,j;


	for(i=0;i<m;i++)
	  {
		at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
	  }


	for(j=1;j<n-1;j++)
	  {
		at[0][j]=t[0][j]=0; at[m-1][j]=t[m-1][j]=0;

	  }


	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
	  {

		 at[i][j]=0.5*(t[i-1][j]+t[i][j-1]+t[i+1][j]+t[i][j+1]-4*t[i][j]);
	  }


 }

 

 void matmul_fine(double t[][n+5],double at[][n+5]) 
  {
	int i,j;


	for(i=0;i<m;i++)
	  {
		at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
	  }


	for(j=1;j<n-1;j++)
	  {
		at[0][j]=t[0][j]=0; at[m-1][j]=t[m-1][j]=0;

	  }


	for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
	  {

		 at[i][j]=0.5*(t[i-1][j]+t[i][j-1]+t[i+1][j]+t[i][j+1]-4*t[i][j]);
		 at[i][j]+=-0.5*dt*(m-1)*(m-1)*(t[i-1][j-1]-8*t[i][j-1]+t[i+1][j-1]-8*t[i-1][j]+28*t[i][j]-8*t[i+1][j]+t[i-1][j+1]-8*t[i][j+1]+t[i+1][j+1])/re;
	  }


 }

 

  double norm(s)
  double s[][n+5];
  {
    int i,j;
    double x2n=0.0;

    for(j=0;j<n;j++)for(i=0;i<m;i++)  x2n += s[i][j]*s[i][j];
    x2n=sqrt(x2n);
    return(x2n);

  }

  double vecmul_fine(v,s)
  double v[][n+5],s[][n+5];
  {
   int i,j;
   double r=0.0;
   for(j=0;j<n;j++)for(i=0;i<m;i++)  r += v[i][j]*s[i][j];
   return(r);
  }
 double max(double s[][n+5])
     {
	int i,j;
        double v=fabs(s[0][0]);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         if(fabs(s[i][j])>=v)  v=fabs(s[i][j]);
         else v=v;
       }
         return(v);

     }