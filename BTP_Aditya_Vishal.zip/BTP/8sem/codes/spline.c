#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define m 81
#define n 81

#define mf 81
#define nf 81
#define mag 10
#define re 100
#define h 1/((float) (m-1))
#define pi 4*atan(1.0)

int i,j,ite,it1=0,tag;
  double u[m+5][n+5],v[m+5][n+5];
  double max(),bb[m+5][n+5];
  double at1[m+5][n+5],bt1[m+5][n+5],
         ct1[m+5][n+5],ct2[m+5][n+5],dt1[m+5][n+5],dt2[m+5][n+5];
  double bb1[m+5][n+5],xn[m+5][n+5],bn[m+5][n+5],xx[m+5][n+5],r[m+5][n+5],
      b[m+5][n+5],p[m+5][n+5],w[m+5][n+5],a1,b1,err=.5e-7;
  double v1[m+5][n+5],t2[m+5][n+5],s[m+5][n+5],r1[m+5][n+5],w1,w2,l1;
  double cu2,cu8,cv4,cv6;
  double vecmul(),e1[m+5][n+5],f1[m+5][n+5],xm[m+5][n+5];
  double nn,mu,ta,xx1,yy1,xx2,yy2,k,val(),r0,rn,ii,jj;
  double err1=0.5e-6,norm();

  FILE *pt,*pt2,*pt1;
  int itef,itf1=0,tagf;
  double u_fine[m+5][n+5],v_fine[m+5][n+5];
  double bb_fine[m+5][n+5];
  double at1_fine[m+5][n+5],bt1_fine[m+5][n+5],
         ct1_fine[m+5][n+5],ct2_fine[m+5][n+5],dt1_fine[m+5][n+5],dt2_fine[m+5][n+5];
  double bb1_fine[m+5][n+5],xn_fine[m+5][n+5],bn_fine[m+5][n+5],xx_fine[m+5][n+5],r_fine[m+5][n+5],
      b_fine[m+5][n+5],p_fine[m+5][n+5],w_fine[m+5][n+5],a1_fine,b1_fine;
  double v1_fine[m+5][n+5],t2_fine[m+5][n+5],s_fine[m+5][n+5],r1_fine[m+5][n+5];
  
  double e1_fine[m+5][n+5],f1_fine[m+5][n+5],xm_fine[m+5][n+5];
  double err1_fine = 0.5e-17, err_fine = 0.5e-19;
  
  void matmul(double t[][n+5],double at[][n+5]) 
  {
    int i,j;
    double c1,c2,c3,c4,c5,c6,c7,c8,c9;
    for(i=0;i<m;i++)
    {
      at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
    } 


    for(j=1;j<n-1;j++)
    {
      at[0][j]=t[0][j]=0; at[m-1][j]=t[m-1][j]=0;
    }


    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
    {

     at[i][j]=t[i-1][j-1]-8*t[i][j-1]+t[i+1][j-1];
     at[i][j]+=-8*t[i-1][j]+28*t[i][j]-8*t[i+1][j];
     at[i][j]+=t[i-1][j+1]-8*t[i][j+1]+t[i+1][j+1];
    }
  }

  void matmul_fine(double t[][n+5],double at[][n+5]) 
  {
    int i,j;
    double c1,c2,c3,c4,c5,c6,c7,c8,c9;
    for(i=0;i<m;i++)
    {
      at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
    } 


    for(j=1;j<n-1;j++)
    {
      at[0][j]=t[0][j]; at[m-1][j]=t[m-1][j];
    }


    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
    {

     at[i][j]=t[i-1][j-1]-8*t[i][j-1]+t[i+1][j-1];
     at[i][j]+=-8*t[i-1][j]+28*t[i][j]-8*t[i+1][j];
     at[i][j]+=t[i-1][j+1]-8*t[i][j+1]+t[i+1][j+1];
    }
  }  
  
  
  float* initialise(int num)
  {
    float *a ;
    a =  (float*)malloc(num*sizeof(float));
    return a;
  }

  void cubic_spline(int num,float *x,float *y,float *a,float *b,float *c,float *d)
  {
    //S(x) = Sj(x) = aj + bj(x - xj) + cj(x - xj)^2 + dj(x - xj)^3
    //Initialisation
    int i;
    for(int i = 0;i<=num-1;i++)
    {
      a[i] = y[i];
    }
  
    float *x_h,*alpha,*l,*mu,*z;
  
    x_h = initialise(num);
    for(i=0;i<=num-1;i++){
      x_h[i] = x[i+1]-x[i];
    }

    alpha = initialise(num+1);
    for(i=1;i<=num-1;i++){
      alpha[i] = 3*(a[i+1]-a[i])/x_h[i] - 3*(a[i]-a[i-1])/x_h[i-1];
    }
    //Steps solving a tridiagonal linear system

    l = initialise(num+1);
    mu = initialise(num+1);
    z = initialise(num+1);
    l[0] = 1; mu[0] = 0; z[0] = 0;

    for(i=1;i<=num-1;i++)
    {
      l[i] = 2.0*(x[i+1]-x[i-1]) - x_h[i-1]*mu[i-1];
      mu[i] = x_h[i]/l[i];
      z[i] = (alpha[i] - x_h[i-1]*z[i-1])/l[i];
    }
    l[num] = 1; z[num] = 0; c[num] = 0;

    for(i=num-1;i>=0;i--)
    {
      c[i] = z[i] - mu[i]*c[i+1];
      b[i] = (a[i+1] - a[i])/x_h[i] - x_h[i]*(c[i+1]+2*c[i])/3.0;
      d[i] = (c[i+1]-c[i])/(3*x_h[i]);
    }
    free(x_h);
    free(alpha);
    free(l);
    free(mu);
    free(z);

  }
  int main()
{ //ofstream out;


  int num = 100;
  float *x,*y,*a,*b,*c,*d;
  int i,j;
  int m_finer = m; int n_finer = n;
  x = initialise(num+1);
  y = initialise(num+1);
  a = initialise(num);
  b = initialise(num);
  c = initialise(num+1);
  d = initialise(num);
  //top boundary
  for(j=0;j<=100;j++) x[j] = j;
  
  for(j=0;j<=100;j++) y[j] = rand()%10;
  cubic_spline(num,x,y,a,b,c,d);

float newx[1001];

for(j=0;j<=1000;j+=mag) newx[j]= y[j/mag]; 
for(j=0;j<num;j++) for(i=1;i<mag;i++)newx[mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;


for(j=0;j<1001;j++) printf("%f \n",newx[j]);

printf("\n");




}