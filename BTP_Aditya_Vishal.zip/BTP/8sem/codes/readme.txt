btpv1.c: coarse conv. - fine conv. (met sir's benchmark)
btpv2.c: heuristics (no improvement)
btpv3.c: back and forth for some steps (worked!)
btpv3_uv.c: uv finite difference rather than interpolation (same results) 
btpv4.c: back and forth and finer conv.
btpv5.c: generic code


In generic code, the finer and coarse grid sizes need not be the same.
