#ifndef MYCLOCK
#define MYCLOCK

void clock_start(void);
double clock_stop(void);

#endif











