
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define m 81
#define n 81

#define mf 81
#define nf 81
#define mag 4
#define re 100
#define h 1/((float) (m-1))
#define pi 4*atan(1.0)

int i,j,ite,it1=0,tag;
  double u[m+5][n+5],v[m+5][n+5];
  double max(),bb[m+5][n+5];
  double at1[m+5][n+5],bt1[m+5][n+5],
         ct1[m+5][n+5],ct2[m+5][n+5],dt1[m+5][n+5],dt2[m+5][n+5];
  double bb1[m+5][n+5],xn[m+5][n+5],bn[m+5][n+5],xx[m+5][n+5],r[m+5][n+5],
      b[m+5][n+5],p[m+5][n+5],w[m+5][n+5],a1,b1,err=.5e-7;
  double v1[m+5][n+5],t2[m+5][n+5],s[m+5][n+5],r1[m+5][n+5],w1,w2,l1;
  double cu2,cu8,cv4,cv6;
  double vecmul(),e1[m+5][n+5],f1[m+5][n+5],xm[m+5][n+5];
  double nn,mu,ta,xx1,yy1,xx2,yy2,k,val(),r0,rn,ii,jj;
  double err1=0.5e-6,norm();

  FILE *pt,*pt2,*pt1;
  int itef,itf1=0,tagf;
  double u_fine[m+5][n+5],v_fine[m+5][n+5];
  double bb_fine[m+5][n+5];
  double at1_fine[m+5][n+5],bt1_fine[m+5][n+5],
         ct1_fine[m+5][n+5],ct2_fine[m+5][n+5],dt1_fine[m+5][n+5],dt2_fine[m+5][n+5];
  double bb1_fine[m+5][n+5],xn_fine[m+5][n+5],bn_fine[m+5][n+5],xx_fine[m+5][n+5],r_fine[m+5][n+5],
      b_fine[m+5][n+5],p_fine[m+5][n+5],w_fine[m+5][n+5],a1_fine,b1_fine;
  double v1_fine[m+5][n+5],t2_fine[m+5][n+5],s_fine[m+5][n+5],r1_fine[m+5][n+5];
  
  double e1_fine[m+5][n+5],f1_fine[m+5][n+5],xm_fine[m+5][n+5];
  double err1_fine = 0.5e-17, err_fine = 0.5e-19;
  
  void matmul(double t[][n+5],double at[][n+5]) 
  {
    int i,j;
    double c1,c2,c3,c4,c5,c6,c7,c8,c9;
    for(i=0;i<m;i++)
    {
      at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
    } 


    for(j=1;j<n-1;j++)
    {
      at[0][j]=t[0][j]=0; at[m-1][j]=t[m-1][j]=0;
    }


    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
    {

     at[i][j]=t[i-1][j-1]-8*t[i][j-1]+t[i+1][j-1];
     at[i][j]+=-8*t[i-1][j]+28*t[i][j]-8*t[i+1][j];
     at[i][j]+=t[i-1][j+1]-8*t[i][j+1]+t[i+1][j+1];
    }
  }

  void matmul_fine(double t[][n+5],double at[][n+5]) 
  {
    int i,j;
    double c1,c2,c3,c4,c5,c6,c7,c8,c9;
    for(i=0;i<m;i++)
    {
      at[i][0]=t[i][0]; at[i][n-1]=t[i][n-1];
    } 


    for(j=1;j<n-1;j++)
    {
      at[0][j]=t[0][j]; at[m-1][j]=t[m-1][j];
    }


    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
    {

     at[i][j]=t[i-1][j-1]-8*t[i][j-1]+t[i+1][j-1];
     at[i][j]+=-8*t[i-1][j]+28*t[i][j]-8*t[i+1][j];
     at[i][j]+=t[i-1][j+1]-8*t[i][j+1]+t[i+1][j+1];
    }
  }  
  
  
  float* initialise(int num)
  {
    float *a ;
    a =  (float*)malloc(num*sizeof(float));
    return a;
  }

  void cubic_spline(int num,float *x,float *y,float *a,float *b,float *c,float *d)
  {
    //S(x) = Sj(x) = aj + bj(x - xj) + cj(x - xj)^2 + dj(x - xj)^3
    //Initialisation
    int i;
    for(int i = 0;i<=num-1;i++)
    {
      a[i] = y[i];
    }
  
    float *x_h,*alpha,*l,*mu,*z;
  
    x_h = initialise(num);
    for(i=0;i<=num-1;i++){
      x_h[i] = x[i+1]-x[i];
    }

    alpha = initialise(num+1);
    for(i=1;i<=num-1;i++){
      alpha[i] = 3*(a[i+1]-a[i])/x_h[i] - 3*(a[i]-a[i-1])/x_h[i-1];
    }
    //Steps solving a tridiagonal linear system

    l = initialise(num+1);
    mu = initialise(num+1);
    z = initialise(num+1);
    l[0] = 1; mu[0] = 0; z[0] = 0;

    for(i=1;i<=num-1;i++)
    {
      l[i] = 2.0*(x[i+1]-x[i-1]) - x_h[i-1]*mu[i-1];
      mu[i] = x_h[i]/l[i];
      z[i] = (alpha[i] - x_h[i-1]*z[i-1])/l[i];
    }
    l[num] = 1; z[num] = 0; c[num] = 0;

    for(i=num-1;i>=0;i--)
    {
      c[i] = z[i] - mu[i]*c[i+1];
      b[i] = (a[i+1] - a[i])/x_h[i] - x_h[i]*(c[i+1]+2*c[i])/3.0;
      d[i] = (c[i+1]-c[i])/(3*x_h[i]);
    }
    free(x_h);
    free(alpha);
    free(l);
    free(mu);
    free(z);

  }
  void interpolate_boundary_conditions(int num)
{ //ofstream out;
  float *x,*y,*a,*b,*c,*d;
  int i,j;
  int m_finer = m; int n_finer = n;
  x = initialise(num+1);
  y = initialise(num+1);
  a = initialise(num);
  b = initialise(num);
  c = initialise(num+1);
  d = initialise(num);
  //top boundary
  for(j=0;j<=num;j++) x[j] = j;
  
  for(j=0;j<=num;j++) y[j] = xx[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xx_fine[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
    
for(j=0;j<=num;j++) y[j] = u[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)u_fine[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
for(j=0;j<=num;j++) y[j] = v[j][m_finer/mag];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)v_fine[mag*j+i][m_finer-1] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;


for(j=0;j<n_finer;j++) xx_fine[j][n_finer-1] = xx_fine[j][n_finer-1]/mag;

for(j=0;j<n_finer;j++){bb1_fine[j][n_finer-1]=xx_fine[j][n_finer-1];xm_fine[j][n_finer-1]=xx_fine[j][n_finer-1];xn_fine[j][n_finer-1]=xx_fine[j][n_finer-1]; }

//right boundary 

for(j=0;j<=num;j++) y[j] = u[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)u_fine[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
for(j=0;j<=num;j++) y[j] = v[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)v_fine[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;


  for(j=0;j<=num;j++) y[j] = xx[num][j];
  cubic_spline(num,x,y,a,b,c,d);
  for(j=0;j<num;j++) for(i=1;i<mag;i++)xx_fine[n_finer-1][mag*j+i] = a[j] + pow((float)((1/((float) (mag)))*(float)i),1)*b[j] + pow((float)((1/((float) (mag)))*(float)i),2)*c[j] +pow((float)((1/((float) (mag)))*(float)i),3)*d[j] ;
  
for(j=0;j<n_finer;j++) xx_fine[n_finer-1][j] = xx_fine[n_finer-1][j]/mag;  
for(j=0;j<n_finer;j++){bb1_fine[n_finer-1][j]=xx_fine[n_finer-1][j];xm_fine[n_finer-1][j]=xx_fine[n_finer-1][j];xn_fine[n_finer-1][j]=xx_fine[n_finer-1][j]; }


    free(x);
    free(y);
    free(a);
    free(b);
    free(c);
    free(d);

}

  void initialise_coarser()
  {
    for(j=1;j<n-1;j++)
    {
      u[0][j]=v[0][j]=0;
      u[m-1][j]=v[m-1][j]=0;
    }

    for(i=0;i<m;i++)
    {
      u[i][n-1]=1;
      u[i][0]=v[i][0]=v[i][n-1]=0; 
    }

    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u[i][j]=v[i][j]=0.000;

    for(j=0;j<n;j++)
    {
      xx[0][j]=xn[0][j]=bb1[0][j]=0.00;
      xx[m-1][j]=xn[m-1][j]=bb1[m-1][j]=0.00;
    }
    
    for(i=1;i<m-1;i++)
    {
      xx[i][0]=xn[i][0]=bb1[i][0]=0.00;
      xx[i][n-1]=xn[i][n-1]=bb1[i][n-1]=0.00;
    }
    for(j=1;j<n-1;j++)for(i=1;i<m-1;i++){xx[i][j]=xn[i][j]=0.00;}

    /*pt2=fopen("dctty.dat","r+");
    for(j=0;j<n;j++)for(i=0;i<m;i++)
    fscanf(pt2,"%lf %lf %lf %lf %lf",&ii,&jj,&u[i][j],&v[i][j],&xx[i][j]);
    for(j=0;j<n;j++)for(i=0;i<m;i++)xn[i][j]=xx[i][j];
    fclose(pt2);*/  
  }

  void coarse_solver(){
    do
    {

      tag=1;it1++;
      for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
      {
        bb1[i][j]=3*h*(u[i][j-1]-v[i-1][j]+v[i+1][j]-u[i][j+1]);
        bb1[i][j]+=-0.5*re*h*h*u[i][j]*(v[i][j-1]+v[i][j+1]+v[i-1][j]+v[i+1][j]);
        bb1[i][j]+=0.5*re*h*h*v[i][j]*(u[i][j-1]+u[i][j+1]+u[i-1][j]+u[i+1][j]);
      }
      /*BEGINING OF BICONJUGATE GRADIENT*/
      matmul(xx,r);
      for(j=0;j<n;j++)for(i=0;i<m;i++)
      {              
        r1[i][j] = r[i][j] = bb1[i][j] - r[i][j];
        v1[i][j]=p[i][j]=0;
      }
      ite=0;
      r0=a1=w1=1;
      while(norm(r) > err)/*loop for iteration begins*/
      {
        ite++;
        r0=-w1*r0;
        rn=vecmul(r,r1);
        b1=(rn)*(a1)/r0;
        for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
          xm[i][j]=xx[i][j];
          p[i][j]=r[i][j]-b1*(p[i][j]-w1*v1[i][j]);
        }
        matmul(p,v1);
        a1=rn/vecmul(r1,v1);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
          s[i][j] =r[i][j]- a1*v1[i][j];
        r0=rn;
        matmul(s,t2);
        w1=vecmul(t2,s)/vecmul(t2,t2);
        if(rn==0)break;
        for(j=0;j<n;j++)for(i=0;i<m;i++)
        {
          xx[i][j]+=a1*p[i][j]+w1*s[i][j];r[i][j]=s[i][j]-w1*t2[i][j];
          xx[i][j]=xm[i][j]+0.85*(xx[i][j]-xm[i][j]);
        }
      }

      /*END OF BICONJUGATE GRADIENT*/

      l1=0.85;
      for(j=0;j<n;j++)for(i=0;i<m;i++)
      {
        e1[i][j]=xx[i][j]-xn[i][j];xx[i][j]=xn[i][j]+l1*e1[i][j];
        xn[i][j]=xx[i][j];
      }
 
      /* Calculation of u*/

      for(i=1;i<m-1;i++)
      {
        ct1[i][1]=ct2[i][1]=3*(m-1)*(xx[i][2]-xx[i][0])-u[i][0];
        ct1[i][n-2]=ct2[i][n-2]=3*(m-1)*(xx[i][n-1]-xx[i][n-3])-u[i][n-1];

        for(j=2;j<n-2;j++)ct1[i][j]=3*(m-1)*(xx[i][j+1]-xx[i][j-1]);

        for(j=1;j<n-1;j++)
        {
          bt1[i][j]=at1[i][j]=1;dt1[i][j]=dt2[i][j]=4;}
          bt1[i][1]=0;at1[i][n-2]=0;

          for(j=2;j<n-1;j++)dt2[i][j]=dt1[i][j]-(bt1[i][j]*at1[i][j-1])/(dt2[i][j-1]);
          for(j=2;j<n-1;j++)ct2[i][j]=ct1[i][j]-(ct2[i][j-1]*bt1[i][j])/(dt2[i][j-1]);
          u[i][n-2]=ct2[i][n-2]/dt2[i][n-2];
          for(j=n-3;j>0;j--)u[i][j]=(ct2[i][j]-at1[i][j]*u[i][j+1])/dt2[i][j];
        }


      /* Calculation of v*/

      for(j=1;j<n-1;j++)
      {
        ct1[1][j]=ct2[1][j]=3*(m-1)*(xx[0][j]-xx[2][j])-v[0][j];
        ct1[m-2][j]=ct2[m-2][j]=3*(m-1)*(xx[m-3][j]-xx[m-1][j])-v[m-1][j];

        for(i=2;i<m-2;i++)ct1[i][j]=3*(m-1)*(xx[i-1][j]-xx[i+1][j]);

        for(i=1;i<m-1;i++)
        {
          bt1[i][j]=at1[i][j]=1;
          dt1[i][j]=dt2[i][j]=4;
        }
          bt1[1][j]=0;at1[m-2][j]=0;

          for(i=2;i<m-1;i++)dt2[i][j]=dt1[i][j]-(bt1[i][j]*at1[i-1][j])/(dt2[i-1][j]);
          for(i=2;i<m-1;i++)ct2[i][j]=ct1[i][j]-(ct2[i-1][j]*bt1[i][j])/(dt2[i-1][j]);
          v[m-2][j]=ct2[m-2][j]/dt2[m-2][j];
          for(i=m-3;i>0;i--)v[i][j]=(ct2[i][j]-at1[i][j]*v[i+1][j])/dt2[i][j];
      }

 //////////////////////
    /*for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
      {
        u[i][j]=0.5*(m-1)*(xx[i][j+1]-xx[i][j-1]);v[i][j]=0.5*(m-1)*(xx[i-1][j]-xx[i+1][j]);}*/
    /*  if(max(e1)<err1)l1=.1*l1;*/
        printf("%d %lf %lf %e\n",it1,u[20][20],v[20][20],max(e1));

        if(((int) it1/10)*10==it1)
        {  
          pt2=fopen("dct11.dat","w+");
          for(j=0;j<n;j++) 
          {
           fprintf(pt2,"\n");
           for(i=0;i<m;i++)fprintf(pt2,"%lf %lf %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j]); 
          }
            fclose(pt2);
        }  
      /*if(norm(f1)/((float) (m-1))<err1)tag=0;*/
       if(max(e1)<err1)tag=0;
       //if(it1>3800)break;
      }while(tag==1);
  
   pt1=fopen("vals_coarse.dat","w+");
    fprintf(pt1,"variables=x,y,u,v,s\n");
    fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
    for(j=0;j<n;j++) for(i=0;i<m;i++)
    {
 fprintf(pt1,"%lf %lf %e %e %e\n",i*h,j*h,u[i][j],v[i][j],xx[i][j]);

    }
    fclose(pt1);
  
  }
void updatefinerfromcoarser(){

int n_fine = n;
int m_fine = m;
for(i=0;i<n_fine;i+=mag)
 for(j=0;j<m_fine;j+=mag)
{  


  xn_fine[i][j] = xn[i/mag][j/mag];
  xx_fine[i][j] = xx[i/mag][j/mag];
  xm_fine[i][j] = xm[i/mag][j/mag];
  bb1_fine[i][j] = bb1[i/mag][j/mag];
  u_fine[i][j] = u[i/mag][j/mag];
  v_fine[i][j] = v[i/mag][j/mag];
  w_fine[i][j]  = w[i/mag][j/mag];

 } 
  
  interpolate_boundary_conditions(n/mag);




 }

void initialise_finer(){
 for(j=1;j<n-1;j++)
 {
    u_fine[0][j]=v_fine[0][j]=0;
    u_fine[m-1][j]=v_fine[m-1][j]=0;
 }

  for(i=0;i<m;i++)
   {
  u_fine[i][n-1]=1;
  u_fine[i][0]=v_fine[i][0]=v_fine[i][n-1]=0; 
   }

  for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)u_fine[i][j]=v_fine[i][j]=0.000;

  for(j=0;j<n;j++)
    {
      xx_fine[0][j]=xn_fine[0][j]=bb1_fine[0][j]=0.00;
      xx_fine[m-1][j]=xn_fine[m-1][j]=bb1_fine[m-1][j]=0.00;
    }


  
     for(i=1;i<m-1;i++)
  {
    xx_fine[i][0]=xn_fine[i][0]=bb1_fine[i][0]=0.00;
    xx_fine[i][n-1]=xn_fine[i][n-1]=bb1_fine[i][n-1]=0.00;
  }
  for(j=1;j<n-1;j++)for(i=1;i<m-1;i++){xx_fine[i][j]=xn_fine[i][j]=0.00;}
  
  updatefinerfromcoarser(); 
}
 


void updatecoarserfromfiner()
{
int n_finer = n;
int m_finer = n;
for(i=0;i<n_finer;i+=mag)
 for(j=0;j<m_finer;j+=mag)
 {  
    xn[i/mag][j/mag] = xn_fine[i][j] ;
    xx[i/mag][j/mag] = xx_fine[i][j];
    xm[i/mag][j/mag] = xm_fine[i][j];

    w[i/mag][j/mag] =  w_fine[i][j] ;
    //wn[i/mag][j/mag] =  wn_finer[i][j];
    //wm[i/mag][j/mag] = wm_finer[i][j] ;
  }

}

  double norm(s)
  double s[][n+5];
  {
    int i,j;
    double x2n=0.0;

    for(j=0;j<n;j++)for(i=0;i<m;i++)  x2n += s[i][j]*s[i][j];
    x2n=sqrt(x2n);
    return(x2n);

  }

  double vecmul(v,s)
  double v[][n+5],s[][n+5];
  {
   int i,j;
   double r=0.0;
   for(j=0;j<n;j++)for(i=0;i<m;i++)  r += v[i][j]*s[i][j];
   return(r);
  }
 double max(double s[][n+5])
     {
  int i,j;
        double v=fabs(s[0][0]);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         if(fabs(s[i][j])>=v)  v=fabs(s[i][j]);
         else v=v;
       }
         return(v);

}

void fine_solver(){  

 float hf = h/(float)mag;
do
 {

  tagf=1;itf1++;
  
  
  for(j=1;j<n-1;j++)for(i=1;i<m-1;i++)
    {
     bb1_fine[i][j]=3*hf*(u_fine[i][j-1]-v_fine[i-1][j]+v_fine[i+1][j]-u_fine[i][j+1]);
     bb1_fine[i][j]+=-0.5*re*hf*hf*u_fine[i][j]*(v_fine[i][j-1]+v_fine[i][j+1]+v_fine[i-1][j]+v_fine[i+1][j]);
     bb1_fine[i][j]+=0.5*re*hf*hf*v_fine[i][j]*(u_fine[i][j-1]+u_fine[i][j+1]+u_fine[i-1][j]+u_fine[i+1][j]);
    }

     /*BEGINING OF BICONJUGATE GRADIENT*/
    matmul_fine(xx_fine,r_fine);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
               {               
       r1_fine[i][j] = r_fine[i][j] = bb1_fine[i][j] - r_fine[i][j];
       v1_fine[i][j]=p_fine[i][j]=0;
         }
               itef=0;
         r0=a1_fine=w1=1;
         while(norm(r_fine) > err_fine)/*loop for itefration begins*/
         {
           itef++;
           r0=-w1*r0;
           rn=vecmul(r_fine,r1_fine);
           b1_fine=(rn)*(a1_fine)/r0;
        for(j=0;j<n;j++)for(i=0;i<m;i++)
           {
             xm_fine[i][j]=xx_fine[i][j];
             p_fine[i][j]=r_fine[i][j]-b1_fine*(p_fine[i][j]-w1*v1_fine[i][j]);
           }
       matmul_fine(p_fine,v1_fine);
           a1_fine=rn/vecmul(r1_fine,v1_fine);
        for(j=0;j<n;j++)for(i=0;i<m;i++)
             s_fine[i][j] =r_fine[i][j]- a1_fine*v1_fine[i][j];
           r0=rn;
       matmul_fine(s_fine,t2_fine);
           w1=vecmul(t2_fine,s_fine)/vecmul(t2_fine,t2_fine);
           if(rn==0)break;
        for(j=0;j<n;j++)for(i=0;i<m;i++)
    {
         xx_fine[i][j]+=a1_fine*p_fine[i][j]+w1*s_fine[i][j];r_fine[i][j]=s_fine[i][j]-w1*t2_fine[i][j];
         xx_fine[i][j]=xm_fine[i][j]+0.125*(xx_fine[i][j]-xm_fine[i][j]);
           }
           
    
         }
         /*END OF BICONJUGATE GRADIENT*/

     l1=0.85;
     for(j=0;j<n;j++)for(i=0;i<m;i++)
       {
         e1_fine[i][j]=xx_fine[i][j]-xn_fine[i][j];xx_fine[i][j]=xn_fine[i][j]+l1*e1_fine[i][j];
   xn_fine[i][j]=xx_fine[i][j];
       }



  for(j=1;j<n;j++)
   {
        v_fine[m-1][j]=(xx_fine[m-2][j]-xx_fine[m-1][j])/hf;
   }

  for(j=1;j<n;j++)
   {
	u_fine[m-1][j]=(xx_fine[m-1][j+1]-xx_fine[m-1][j-1])/(2*hf);
   }
  for(i=1;i<m-1;i++)
   {
	u_fine[i][n-1]=(xx_fine[i][n-1]-xx_fine[i][n-2])/hf;
        v_fine[i][n-1]=(xx_fine[i-1][n-1]-xx_fine[i+1][n-1])/(2*hf);
   }
  for(j=0;j<n;j++) u_fine[0][j]=v_fine[0][j]=xx_fine[0][j]=xn_fine[0][j]=0;
  for(i=0;i<m;i++)u_fine[i][0]=v_fine[i][0]=xx_fine[i][0]=xn_fine[i][0]=0;


                 /* Calculation of u*/

   for(i=1;i<m-1;i++)
    {
     ct1_fine[i][1]=ct2_fine[i][1]=3*(m-1)*(xx_fine[i][2]-xx_fine[i][0])-u_fine[i][0];
     ct1_fine[i][n-2]=ct2_fine[i][n-2]=3*(m-1)*(xx_fine[i][n-1]-xx_fine[i][n-3])-u_fine[i][n-1];

     for(j=2;j<n-2;j++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i][j+1]-xx_fine[i][j-1]);

     for(j=1;j<n-1;j++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[i][1]=0;at1_fine[i][n-2]=0;

   for(j=2;j<n-1;j++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i][j-1])/(dt2_fine[i][j-1]);
   for(j=2;j<n-1;j++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i][j-1]*bt1_fine[i][j])/(dt2_fine[i][j-1]);
   u_fine[i][n-2]=ct2_fine[i][n-2]/dt2_fine[i][n-2];
   for(j=n-3;j>0;j--)u_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*u_fine[i][j+1])/dt2_fine[i][j];

    }


              /* Calculation of v*/

   for(j=1;j<n-1;j++)
    {
     ct1_fine[1][j]=ct2_fine[1][j]=3*(m-1)*(xx_fine[0][j]-xx_fine[2][j])-v_fine[0][j];
     ct1_fine[m-2][j]=ct2_fine[m-2][j]=3*(m-1)*(xx_fine[m-3][j]-xx_fine[m-1][j])-v_fine[m-1][j];

     for(i=2;i<m-2;i++)ct1_fine[i][j]=3*(m-1)*(xx_fine[i-1][j]-xx_fine[i+1][j]);

     for(i=1;i<m-1;i++)
    {bt1_fine[i][j]=at1_fine[i][j]=1;dt1_fine[i][j]=dt2_fine[i][j]=4;}
   bt1_fine[1][j]=0;at1_fine[m-2][j]=0;

   for(i=2;i<m-1;i++)dt2_fine[i][j]=dt1_fine[i][j]-(bt1_fine[i][j]*at1_fine[i-1][j])/(dt2_fine[i-1][j]);
   for(i=2;i<m-1;i++)ct2_fine[i][j]=ct1_fine[i][j]-(ct2_fine[i-1][j]*bt1_fine[i][j])/(dt2_fine[i-1][j]);
   v_fine[m-2][j]=ct2_fine[m-2][j]/dt2_fine[m-2][j];
   for(i=m-3;i>0;i--)v_fine[i][j]=(ct2_fine[i][j]-at1_fine[i][j]*v_fine[i+1][j])/dt2_fine[i][j];

    }

printf("finer %d %lf %lf %e\n",itf1,u_fine[20][20],v_fine[20][20],max(e1_fine));
   if(max(e1_fine)<err1_fine)
      tagf=0;

}while(tagf==1);

  

   pt1=fopen("vals_fine.dat","w+");
    fprintf(pt1,"variables=x,y,u,v,s\n");
    fprintf(pt1,"zone T=\"\",i=%d,j=%d\n",m,n);
    for(j=0;j<n;j++) for(i=0;i<m;i++)
    {
 fprintf(pt1,"%lf %lf %e %e %e\n",i*hf,j*hf,u_fine[i][j],v_fine[i][j],xx_fine[i][j]);

    }
    fclose(pt1);
   for(j=0;j<n;j++) printf("%f ",u_fine[j][n-2]);



   printf("\n\n");

printf("-------\n\n");
for(j=0;j<n;j++) printf("%f ",xx_fine[j][0]); printf("\n\n");
for(j=0;j<n/mag;j++) printf("%f ",xx[j][0]); printf("\n\n");


}

int main(){
  
  initialise_coarser();
  coarse_solver();
  
  initialise_finer();
  fine_solver();
  //printf("\n\nfine 01 \n\n");
  //updatecoarserfromfiner();
  //coarse_solver();
  //updatefinerfromcoarser();
  //fine_solver();
  //updatecoarserfromfiner();
  //coarse_solver();
  //updatefinerfromcoarser();
  //fine_solver();
  //updatecoarserfromfiner();
  //coarse_solver();
  //updatefinerfromcoarser();
  //fine_solver();
  //updatecoarserfromfiner();
  //coarse_solver();
  //updatefinerfromcoarser();
  //fine_solver();
  
  return 0;
}


